import time

import numpy as np
import serial
import serial.tools.list_ports
from scipy import signal

try:
    import tkinter as tk
    from tkinter import messagebox
except Exception:
    tk = None
    messagebox = None


def _show_device_error(message):
    if tk is None or messagebox is None:
        return

    root = None
    try:
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror(title="Device error", message=message)
    except Exception:
        return
    finally:
        if root is not None:
            try:
                root.destroy()
            except Exception:
                pass


class Device:
    MIN_HR_BPM = 40.0
    MAX_HR_BPM = 180.0
    BANDPASS_LOW_HZ = 0.7
    BANDPASS_HIGH_HZ = 4.0
    MIN_ANALYSIS_SECONDS = 4.0
    ANALYSIS_INTERVAL_SECONDS = 0.20
    FINGER_IR_THRESHOLD = 50000
    MIN_PPG_AMPLITUDE = 80.0

    def __init__(self, sample_rate=1600, avg_rate=8, brate=115200, serial_enabled=True):
        self.valid = False
        self.serial_enabled = serial_enabled
        self.brate = brate
        self.port_list = []
        self.port = ""
        self.ser = None

        if self.serial_enabled:
            self.port_list = [i.device for i in serial.tools.list_ports.comports()]
            if len(self.port_list) > 0:
                self.port = self.port_list[0]
            else:
                _show_device_error("No serial device found.")
                return

        self.view_mode = "Dynamic"
        self.filter_mode = "Filter ON"
        if self.serial_enabled:
            self.ser = serial.Serial(self.port, brate)
        self.valid = True

        self.sampe_rate = int(sample_rate)
        self.avg_rate = int(avg_rate)
        self.read_data = ""
        self.data_valid = 0
        self.k = 0
        self.hr_time_start_end = [0, 0]

        self.data_list_time = []
        self.range_list_time = list(range(self.sampe_rate))
        self.ir_list_data = []
        self.red_list_data = []
        self.red_list_show_data = [0] * self.sampe_rate
        self.red_list_show_index = 0
        self.ir_list_data_filtered = []
        self.red_list_data_filtered = []
        self.bpm_list_data = []
        self.SPO2_list_data = []

        self.peak_indices = []
        self.peak_times_ms = []
        self.peak_values = []
        self.last_peak_time_ms = 0
        self._last_analysis_wall_s = 0.0
        self._last_good_hr = 0.0

        self.data = {
            "red": 0,
            "ir": 0,
            "HR": 0,
            "SPO2": 0,
            "Time": 0,
            "Fin": 0,
            "Quality": 0,
            "Beat": 0,
            "Fs": 0.0,
        }

    def _trim_buffers(self):
        overflow = len(self.ir_list_data) - self.sampe_rate
        if overflow <= 0:
            return

        del self.ir_list_data[:overflow]
        del self.red_list_data[:overflow]
        del self.data_list_time[:overflow]

    def _estimate_sample_rate_hz(self):
        if len(self.data_list_time) < 4:
            return 0.0

        times = np.asarray(self.data_list_time[-min(len(self.data_list_time), 300):], dtype=np.float64)
        intervals_ms = np.diff(times)
        intervals_ms = intervals_ms[(intervals_ms > 0.1) & (intervals_ms < 200.0)]
        if intervals_ms.size == 0:
            return 0.0

        fs = 1000.0 / float(np.median(intervals_ms))
        return float(np.clip(fs, 25.0, 400.0))

    def _finger_present(self):
        if len(self.ir_list_data) < 8:
            return False

        recent = np.asarray(self.ir_list_data[-min(len(self.ir_list_data), 80):], dtype=np.float64)
        return float(np.median(recent)) > self.FINGER_IR_THRESHOLD

    def _filter_ppg(self, values, fs_hz):
        raw = np.asarray(values, dtype=np.float64)
        if raw.size < 20 or fs_hz <= 0:
            return raw - np.mean(raw) if raw.size else raw

        detrended = signal.detrend(raw, type="linear")
        high = min(self.BANDPASS_HIGH_HZ, fs_hz * 0.45)
        low = min(self.BANDPASS_LOW_HZ, high * 0.5)
        if low <= 0 or high <= low:
            return detrended

        b, a = signal.butter(3, [low, high], btype="bandpass", fs=fs_hz)
        padlen = 3 * max(len(a), len(b))
        if detrended.size <= padlen:
            return detrended

        try:
            return signal.filtfilt(b, a, detrended)
        except ValueError:
            return detrended

    def _pick_peak_polarity(self, filtered_ir, fs_hz):
        if filtered_ir.size < 8:
            return np.asarray([], dtype=np.int64), filtered_ir

        min_distance = max(1, int(fs_hz * 60.0 / self.MAX_HR_BPM))
        amplitude = float(np.percentile(filtered_ir, 95) - np.percentile(filtered_ir, 5))
        noise = float(np.std(filtered_ir))
        prominence = max(amplitude * 0.12, noise * 0.35, 1.0)

        peaks_pos, props_pos = signal.find_peaks(
            filtered_ir,
            distance=min_distance,
            prominence=prominence,
        )
        peaks_neg, props_neg = signal.find_peaks(
            -filtered_ir,
            distance=min_distance,
            prominence=prominence,
        )

        def score(peaks, props):
            if len(peaks) < 2:
                return 0.0

            times = np.asarray(self.data_list_time, dtype=np.float64)[peaks]
            intervals = np.diff(times) / 1000.0
            intervals = intervals[
                (intervals >= 60.0 / self.MAX_HR_BPM)
                & (intervals <= 60.0 / self.MIN_HR_BPM)
            ]
            if intervals.size == 0:
                return 0.0

            interval_score = 1.0 / (1.0 + float(np.std(intervals) / np.mean(intervals)))
            prominence_score = float(np.median(props.get("prominences", [0.0])))
            return len(intervals) * interval_score * max(prominence_score, 1.0)

        if score(peaks_neg, props_neg) > score(peaks_pos, props_pos):
            return peaks_neg, -filtered_ir

        return peaks_pos, filtered_ir

    def _calculate_spo2(self, filtered_ir, filtered_red):
        if not self.data_valid or filtered_ir.size < 20 or filtered_red.size < 20:
            return 0.0

        ir_dc = float(np.mean(self.ir_list_data))
        red_dc = float(np.mean(self.red_list_data))
        ir_ac = float(np.sqrt(np.mean(np.square(filtered_ir))))
        red_ac = float(np.sqrt(np.mean(np.square(filtered_red))))

        if ir_dc <= 0 or red_dc <= 0 or ir_ac <= 0:
            return 0.0

        ratio = (red_ac / red_dc) / (ir_ac / ir_dc)
        spo2 = -45.060 * ratio * ratio + 30.354 * ratio + 94.845
        if not np.isfinite(spo2) or spo2 < 0 or spo2 > 100:
            return 0.0
        return float(spo2)

    def _analyse_window(self):
        fs_hz = self._estimate_sample_rate_hz()
        self.data["Fs"] = fs_hz
        enough_time = (
            len(self.data_list_time) >= 2
            and (self.data_list_time[-1] - self.data_list_time[0]) >= self.MIN_ANALYSIS_SECONDS * 1000.0
        )
        finger_present = self._finger_present()

        if fs_hz <= 0 or not enough_time or not finger_present:
            self.data_valid = 0
            self.data["Fin"] = 1 if finger_present else 0
            self.data["Quality"] = 0
            if not finger_present:
                self.data["HR"] = 0
                self.data["SPO2"] = 0
            return

        filtered_ir = self._filter_ppg(self.ir_list_data, fs_hz)
        filtered_red = self._filter_ppg(self.red_list_data, fs_hz)
        self.ir_list_data_filtered = filtered_ir.tolist()
        self.red_list_data_filtered = filtered_red.tolist()

        amplitude = float(np.percentile(filtered_ir, 95) - np.percentile(filtered_ir, 5))
        if amplitude < self.MIN_PPG_AMPLITUDE:
            self.data_valid = 0
            self.data["Fin"] = 1
            self.data["Quality"] = 0
            return

        peaks, display_signal = self._pick_peak_polarity(filtered_ir, fs_hz)
        self.ir_list_data_filtered = display_signal.tolist()

        if len(peaks) < 3:
            self.data_valid = 0
            self.data["Fin"] = 1
            self.data["Quality"] = 20
            return

        peak_times = np.asarray(self.data_list_time, dtype=np.float64)[peaks]
        intervals_s = np.diff(peak_times) / 1000.0
        valid_intervals = intervals_s[
            (intervals_s >= 60.0 / self.MAX_HR_BPM)
            & (intervals_s <= 60.0 / self.MIN_HR_BPM)
        ]

        if valid_intervals.size < 2:
            self.data_valid = 0
            self.data["Fin"] = 1
            self.data["Quality"] = 25
            return

        median_interval = float(np.median(valid_intervals))
        interval_tolerance = max(0.18 * median_interval, 0.08)
        robust_intervals = valid_intervals[
            np.abs(valid_intervals - median_interval) <= interval_tolerance
        ]
        if robust_intervals.size >= 2:
            valid_intervals = robust_intervals
            median_interval = float(np.median(valid_intervals))

        raw_hr = 60.0 / median_interval
        interval_cv = float(np.std(valid_intervals) / median_interval) if median_interval > 0 else 1.0
        noise_floor = float(np.median(np.abs(np.diff(display_signal)))) if display_signal.size > 2 else 1.0
        snr_score = np.clip(amplitude / max(noise_floor * 8.0, 1.0), 0.35, 1.0)
        quality = int(np.clip(100.0 * (1.0 - interval_cv * 2.8) * snr_score, 25.0, 100.0))

        if self._last_good_hr > 0:
            alpha = 0.18 if abs(raw_hr - self._last_good_hr) > 25.0 else 0.30
            raw_hr = (1.0 - alpha) * self._last_good_hr + alpha * raw_hr

        self._last_good_hr = raw_hr
        self.bpm_list_data.append(raw_hr)
        if len(self.bpm_list_data) > self.avg_rate:
            self.bpm_list_data.pop(0)

        smoothed_hr = float(np.median(self.bpm_list_data))
        self.data_valid = 1
        self.data["Fin"] = 1
        self.data["Quality"] = quality
        self.data["HR"] = smoothed_hr

        spo2 = self._calculate_spo2(filtered_ir, filtered_red)
        self.SPO2_list_data.append(spo2)
        if len(self.SPO2_list_data) > self.avg_rate:
            self.SPO2_list_data.pop(0)
        nonzero_spo2 = [value for value in self.SPO2_list_data if value > 0]
        self.data["SPO2"] = float(np.median(nonzero_spo2)) if nonzero_spo2 else 0.0

        self.peak_indices = peaks.tolist()
        self.peak_times_ms = peak_times.tolist()
        self.peak_values = display_signal[peaks].tolist()
        self.k = int(peaks[-1])
        self.hr_time_start_end = [int(peaks[-2]), int(peaks[-1])]

        latest_peak_ms = int(peak_times[-1])
        self.data["Beat"] = 1 if latest_peak_ms != self.last_peak_time_ms else 0
        self.last_peak_time_ms = latest_peak_ms

    def _update_one_sample(self, red, ir, sample_time_ms):
        sample_time_ms = int(sample_time_ms)
        if self.data_list_time and sample_time_ms <= self.data_list_time[-1]:
            fs_hz = self._estimate_sample_rate_hz()
            step_ms = int(round(1000.0 / fs_hz)) if fs_hz > 0 else 5
            sample_time_ms = self.data_list_time[-1] + max(1, step_ms)

        self.data["red"] = int(red)
        self.data["ir"] = int(ir)
        self.data["Time"] = sample_time_ms
        self.data["Beat"] = 0

        self.ir_list_data.append(int(ir))
        self.red_list_data.append(int(red))
        self.data_list_time.append(sample_time_ms)

        if self.red_list_show_index < len(self.red_list_show_data):
            self.red_list_show_data[self.red_list_show_index] = int(red)
            self.red_list_show_index += 1
            if self.red_list_show_index >= len(self.red_list_show_data):
                self.red_list_show_index = 0

        self._trim_buffers()

        now = time.monotonic()
        if now - self._last_analysis_wall_s >= self.ANALYSIS_INTERVAL_SECONDS:
            self._last_analysis_wall_s = now
            self._analyse_window()

        return self.data

    def add_transport_sample(self, red, ir, sample_time_ms):
        if self.valid:
            return self._update_one_sample(red, ir, sample_time_ms)
        return self.data

    def add_udp_sample(self, red, ir, sample_time_ms):
        return self.add_transport_sample(red, ir, sample_time_ms)

    def get_data(self):
        if self.valid and self.serial_enabled and self.ser is not None:
            while True:
                try:
                    self.read_data = self.ser.readline().decode("utf-8")
                    break
                except Exception:
                    self.read_data = self.ser.readline().decode("utf-8")
            if "[DATA]" in self.read_data:
                data_list_str = self.read_data.split("]")[1].strip().split(",")
                red = int(data_list_str[0].split("=")[1])
                ir = int(data_list_str[1].split("=")[1])
                sample_time_ms = int(data_list_str[2].split("=")[1])
                self._update_one_sample(red, ir, sample_time_ms)
        return self.data


if __name__ == "__main__":
    max_device = Device()
    while True:
        print(max_device.get_data())
