"""Compatibility launcher for the refactored bio_motion_ui package.

Run as before:
    python "Tool/PC_UI BNO Motion temp.py"
"""

from bio_motion_ui.app import main


if __name__ == "__main__":
    raise SystemExit(main())
