#!/usr/bin/env python3
"""
综合睡眠质量分析模块
- 运动检测（60分权重）- 使用帧间累加算法，正确处理跨0°和来回翻转
- 生命体征检测（30分权重）
- 稳定期检测（10分权重）
- 温度舒适度检测（新增）
"""

import math
import time
import json
from typing import Dict, List, Optional, Tuple


class ComprehensiveSleepAnalyzer:
    """综合睡眠质量分析器"""

    def __init__(self, config: Dict = None):
        self.config = {
            # ========== 评分权重 ==========
            'movement_weight': 0.60,
            'vital_weight': 0.30,
            'stable_weight': 0.10,

            # ========== 运动检测配置 ==========
            'head_activity_threshold': 3.0,
            'head_turn_threshold': 30.0,  # 累加总角度超过30°算大幅动作
            'head_weight': 0.8,

            'body_activity_threshold': 3.0,
            'body_turn_threshold': 30.0,
            'body_weight': 1.5,

            'arm_activity_threshold': 3.0,
            'arm_turn_threshold': 30.0,
            'arm_weight': 0.6,

            # 时间阈值
            'min_activity_duration': 0.5,
            'activity_end_idle_time': 0.5,
            'no_impact_duration': 10.0,
            'mild_impact_duration': 30.0,
            'significant_impact_duration': 120.0,
            'max_duration': 600.0,

            # 恢复时间阈值
            'fast_recovery': 5.0,
            'normal_recovery': 30.0,
            'max_recovery': 300.0,

            # 运动评分参数
            'base_score': 100,
            'max_movement_penalty': 50,

            # ========== 生命体征配置 ==========
            'spo2_normal_min': 94.0,
            'max_spo2_penalty': 5,

            'hr_normal_min': 50,
            'hr_normal_max': 100,
            'max_hr_penalty': 5,

            'temp_diff_threshold': 2.0,
            'cover_off_min_duration': 300,
            'temp_penalty': 10,

            # ========== 温度舒适度配置 ==========
            'comfort_temp': 34.0,  # 舒适温度
            'low_temp_offset': 5.0,  # 低温偏移（低于舒适温度5度）
            'high_temp_offset': 2.0,  # 高温偏移（高于舒适温度2度）
            'temp_abnormal_duration': 120,  # 持续异常时间阈值（2分钟）

            # ========== 稳定期配置 ==========
            'stable_ratio_standard': 0.20,

            # ========== 异常检测配置 ==========
            'abnormal_min_duration': 10,
            'stable_confirm_time': 30,
            'critical_duration': 120,
        }
        if config:
            self.config.update(config)

        self.movement = MovementAnalyzer(self.config)
        self.vital = VitalAnalyzer(self.config)

        self.stable_ratio = 0.0

        self.stats = {
            'start_time': None,
            'end_time': None,
            'total_duration_s': 0,
        }

        self.scores = {
            'movement_score': 100,
            'vital_score': 100,
            'stable_score': 100,
            'total_score': 100,
        }

        self.sleep_quality = "待评估"
        self.is_critical = False
        self.critical_reasons = []

    def add_movement_data(self, timestamp: float,
                          quat_head: Tuple, quat_body: Tuple, quat_arm: Tuple):
        if self.stats['start_time'] is None:
            self.stats['start_time'] = timestamp
        self.movement.add_data(timestamp, quat_head, quat_body, quat_arm)

    def add_vital_data(self, timestamp: float,
                       spo2: float = None, hr: float = None,
                       temp_inside: float = None, temp_outside: float = None):
        if self.stats['start_time'] is None:
            self.stats['start_time'] = timestamp
        self.vital.add_data(timestamp, spo2, hr, temp_inside, temp_outside)

    def finalize(self, end_time: float = None):
        if self.stats['start_time'] is None:
            print("[综合睡眠分析] 无数据")
            return

        if end_time is not None:
            self.stats['end_time'] = end_time
            self.stats['total_duration_s'] = end_time - self.stats['start_time']
        else:
            self.stats['end_time'] = time.time()
            self.stats['total_duration_s'] = self.stats['end_time'] - self.stats['start_time']

        self.movement.finalize(self.stats['end_time'])
        self.vital.finalize(self.stats['end_time'])

        self.stable_ratio = self.movement.get_stable_ratio()

        movement_score = self.movement.get_score()
        vital_score = self.vital.get_score()
        stable_score = self._calculate_stable_score()

        self.scores['movement_score'] = movement_score
        self.scores['vital_score'] = vital_score
        self.scores['stable_score'] = stable_score

        self.is_critical = self.vital.is_critical
        self.critical_reasons = self.vital.critical_reasons.copy()

        if self.is_critical:
            self.scores['total_score'] = 0
            self.sleep_quality = "⚠️ 高度异常"
        else:
            total = (movement_score * self.config['movement_weight'] +
                     vital_score * self.config['vital_weight'] +
                     stable_score * self.config['stable_weight'])
            self.scores['total_score'] = round(total, 1)

            if self.scores['total_score'] >= 90:
                self.sleep_quality = "优秀"
            elif self.scores['total_score'] >= 75:
                self.sleep_quality = "良好"
            elif self.scores['total_score'] >= 60:
                self.sleep_quality = "一般"
            elif self.scores['total_score'] >= 40:
                self.sleep_quality = "较差"
            else:
                self.sleep_quality = "很差"

        self._print_summary()

    def _calculate_stable_score(self) -> float:
        stable_ratio = self.stable_ratio
        if stable_ratio <= 0:
            return 0
        elif stable_ratio >= 0.40:
            return 100
        else:
            if stable_ratio <= 0.20:
                return stable_ratio / 0.20 * 60
            else:
                return 60 + (stable_ratio - 0.20) / 0.20 * 40

    def _print_summary(self):
        duration_min = self.stats['total_duration_s'] / 60
        duration_hour = duration_min / 60

        print("\n" + "=" * 70)
        print("🏆 综合睡眠质量分析报告")
        print("=" * 70)

        print(f"\n📅 睡眠时长: {duration_min:.1f} 分钟 ({duration_hour:.1f} 小时)")
        print(f"📈 综合评分: {self.scores['total_score']:.1f}/100")
        print(f"💤 睡眠质量: {self.sleep_quality}")

        if self.is_critical:
            print("\n⚠️⚠️⚠️ 危险警告 ⚠️⚠️⚠️")
            for reason in self.critical_reasons:
                print(f"   ❗ {reason}")
            print(f"\n   🚨 建议立即就医检查！")

        print("\n" + "-" * 50)
        print("📊 各维度评分明细")
        print("-" * 50)
        print(f"   运动检测 (60%): {self.scores['movement_score']:.1f}/100")
        print(f"   生命体征 (30%): {self.scores['vital_score']:.1f}/100")
        print(f"   稳定期 (10%):  {self.scores['stable_score']:.1f}/100")
        print(f"   ─────────────────────────")
        print(f"   综合评分: {self.scores['total_score']:.1f}/100")

        # 打印温度状态
        temp_status = self.vital.get_temp_status()
        print("\n" + "-" * 50)
        print("🌡️ 温度舒适度状态")
        print("-" * 50)
        print(f"   舒适温度: {temp_status['comfort_temp']}℃")
        print(f"   当前平均温度: {temp_status['current_avg_temp']}℃")
        print(f"   温度状态: {temp_status['temp_status']}")
        if temp_status['low_temp_signal']:
            print(f"   ⚠️ 检测到低温！建议增加被褥")
        if temp_status['high_temp_signal']:
            print(f"   ⚠️ 检测到高温！建议减少被褥或开窗通风")

    def print_full_report(self):
        duration_min = self.stats['total_duration_s'] / 60
        duration_hour = duration_min / 60

        print("\n" + "=" * 70)
        print("🏆 综合睡眠质量分析报告（完整版）")
        print("=" * 70)

        print(f"\n📅 睡眠时长: {duration_min:.1f} 分钟 ({duration_hour:.1f} 小时)")
        print(f"📈 综合评分: {self.scores['total_score']:.1f}/100")
        print(f"💤 睡眠质量: {self.sleep_quality}")

        if self.is_critical:
            print("\n⚠️⚠️⚠️ 危险警告 ⚠️⚠️⚠️")
            for reason in self.critical_reasons:
                print(f"   ❗ {reason}")
            print(f"\n   🚨 建议立即就医检查！")

        print("\n" + "=" * 70)
        print("🏃 第一部分：运动检测分析（权重60%）")
        print("=" * 70)
        self.movement.print_report()

        print("\n" + "=" * 70)
        print("💓 第二部分：生命体征分析（权重30%）")
        print("=" * 70)
        self.vital.print_report()

        print("\n" + "=" * 70)
        print("😴 第三部分：稳定期分析（权重10%）")
        print("=" * 70)
        print(f"\n   稳定期占比: {self.stable_ratio * 100:.1f}%")
        print(f"   稳定期得分: {self.scores['stable_score']:.1f}/100")

        print("\n" + "=" * 70)
        print("📋 评分汇总")
        print("=" * 70)
        print(
            f"   运动得分 × 60%  = {self.scores['movement_score']:.1f} × 0.60 = {self.scores['movement_score'] * 0.60:.1f}")
        print(
            f"   生命体征得分 × 30% = {self.scores['vital_score']:.1f} × 0.30 = {self.scores['vital_score'] * 0.30:.1f}")
        print(
            f"   稳定期得分 × 10% = {self.scores['stable_score']:.1f} × 0.10 = {self.scores['stable_score'] * 0.10:.1f}")
        print(f"   ─────────────────────────")
        print(f"   总分 = {self.scores['total_score']:.1f}")

        print("\n" + "=" * 70)
        print("💡 健康建议")
        print("=" * 70)

        if self.is_critical:
            print("   🚨 立即就医检查！")
        else:
            vital_stats = self.vital.get_stats()
            if vital_stats['spo2_penalty'] >= 3:
                print("   💊 血氧波动较大，建议检查睡眠呼吸情况")
            if vital_stats['hr_penalty'] >= 3:
                print("   💊 心率波动较大，建议规律作息")
            if self.movement.get_total_activities() > 50:
                print("   💊 活动次数较多，建议改善睡眠环境")
            if vital_stats['cover_off_detected']:
                print("   💊 睡眠环境温度可能不适，建议调节室温")

            # 温度舒适度建议
            temp_status = self.vital.get_temp_status()
            if temp_status['low_temp_signal']:
                print("   ❄️ 被内温度过低，建议增加被褥或提高室温")
            if temp_status['high_temp_signal']:
                print("   🔥 被内温度过高，建议减少被褥或开窗通风")

            if self.scores['total_score'] >= 90:
                print("   ✅ 睡眠质量优秀，请保持良好作息习惯！")
            elif self.scores['total_score'] >= 75:
                print("   ✅ 睡眠质量良好，建议继续保持规律作息。")
            elif self.scores['total_score'] >= 60:
                print("   ⚠️ 睡眠质量一般，建议减少睡前使用电子设备。")
            elif self.scores['total_score'] >= 40:
                print("   ⚠️ 睡眠质量较差，建议规律作息，适当运动。")
            else:
                print("   ⚠️ 睡眠质量很差，建议咨询专业人士。")

        print("=" * 70 + "\n")

    def save_report(self, filepath: str):
        report = {
            'summary': {
                'duration_minutes': round(self.stats['total_duration_s'] / 60, 1),
                'duration_hours': round(self.stats['total_duration_s'] / 3600, 1),
                'total_score': self.scores['total_score'],
                'sleep_quality': self.sleep_quality,
                'is_critical': self.is_critical,
                'critical_reasons': self.critical_reasons,
            },
            'scores': {
                'movement_score': self.scores['movement_score'],
                'vital_score': self.scores['vital_score'],
                'stable_score': self.scores['stable_score'],
                'total_score': self.scores['total_score'],
            },
            'movement': self.movement.get_report(),
            'vital': self.vital.get_report(),
            'stable_ratio': self.stable_ratio,
            'temp_comfort': self.vital.get_temp_status(),  # 新增温度舒适度数据
        }
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(report, f, ensure_ascii=False, indent=2)
        print(f"📁 综合报告已保存至: {filepath}")
        self.save_html_report(filepath)

    def save_html_report(self, filepath: str):
        """生成精美的HTML睡眠报告"""
        duration_min = self.stats['total_duration_s'] / 60
        duration_hour = duration_min / 60

        # 获取各维度数据
        movement_data = self.movement.get_report()
        vital_data = self.vital.get_report()
        temp_status = self.vital.get_temp_status()

        html_content = f'''<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>睡眠质量报告 - {time.strftime("%Y-%m-%d %H:%M")}</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{
            background: #e9f0f5;
            font-family: 'Segoe UI', 'Roboto', sans-serif;
            padding: 40px 20px;
        }}
        .report-container {{
            max-width: 1000px;
            margin: 0 auto;
            background: white;
            border-radius: 28px;
            box-shadow: 0 20px 35px -12px rgba(0,0,0,0.2);
            overflow: hidden;
        }}
        .report-content {{ padding: 40px 42px 52px; }}
        .header {{
            text-align: center;
            margin-bottom: 32px;
            border-bottom: 3px solid #b0d4e8;
            padding-bottom: 24px;
        }}
        .header h1 {{
            font-size: 32px;
            background: linear-gradient(135deg, #1f6e8c, #0e4b66);
            background-clip: text;
            -webkit-background-clip: text;
            color: transparent;
        }}
        .summary-grid {{
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            margin-bottom: 40px;
        }}
        .stat-card {{
            flex: 1;
            min-width: 160px;
            background: #f8fbfe;
            border-radius: 28px;
            padding: 18px;
            text-align: center;
            border: 1px solid #e2edf2;
        }}
        .stat-card .label {{ font-size: 14px; color: #4a6f86; margin-bottom: 12px; }}
        .stat-card .value {{ font-size: 42px; font-weight: 800; color: #1a4c64; }}
        .score-total {{ background: linear-gradient(145deg, #1f6e8c, #175e78); }}
        .score-total .value, .score-total .label {{ color: white; }}
        .quality-badge {{ background: #fef7e0; border-left: 6px solid #f4b942; }}
        .alert-critical {{
            background: #fff1f0;
            border-left: 8px solid #c23d2b;
            padding: 20px;
            border-radius: 24px;
            margin-bottom: 36px;
        }}
        .alert-critical h3 {{ color: #b13b2a; margin-bottom: 12px; }}
        .temp-warning {{
            background: #fff8e7;
            border-left: 8px solid #f4a942;
            padding: 16px 20px;
            border-radius: 20px;
            margin-bottom: 20px;
        }}
        .temp-cold {{ border-left-color: #4a90e2; background: #e8f0fe; }}
        .temp-hot {{ border-left-color: #e25c4a; background: #fee8e5; }}
        .section {{
            margin-top: 38px;
            border: 1px solid #e2edf2;
            border-radius: 28px;
            overflow: hidden;
        }}
        .section-title {{
            background: #f0f6fa;
            padding: 16px 28px;
            font-size: 22px;
            font-weight: 700;
            color: #134b64;
        }}
        .section-content {{ padding: 24px 32px; }}
        .metrics-row {{ display: flex; flex-wrap: wrap; gap: 20px; margin-bottom: 20px; }}
        .metric-box {{
            flex: 1;
            background: #f9fdfe;
            border-radius: 20px;
            padding: 14px;
            text-align: center;
        }}
        .metric-number {{ font-size: 28px; font-weight: 800; color: #0e5b78; }}
        .badge-dist {{
            background: #eef3f7;
            padding: 6px 14px;
            border-radius: 60px;
            font-size: 14px;
            display: inline-block;
            margin: 4px;
        }}
        .temp-badge {{
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 600;
        }}
        .temp-normal {{ background: #d4edda; color: #155724; }}
        .temp-low {{ background: #cce5ff; color: #004085; }}
        .temp-high {{ background: #f8d7da; color: #721c24; }}
        hr {{ margin: 20px 0; border-top: 2px dotted #c9dfea; }}
        .footer-note {{
            margin-top: 40px;
            text-align: center;
            font-size: 13px;
            color: #7f9bb0;
            border-top: 1px solid #e2edf2;
            padding-top: 28px;
        }}
        @media (max-width: 680px) {{
            .report-content {{ padding: 24px 18px; }}
        }}
    </style>
</head>
<body>
<div class="report-container">
    <div class="report-content">
        <div class="header">
            <h1>🌙 综合睡眠质量分析报告</h1>
            <div>生成时间: {time.strftime("%Y-%m-%d %H:%M:%S")}</div>
        </div>

        <div class="summary-grid">
            <div class="stat-card">
                <div class="label">⏱️ 睡眠时长</div>
                <div class="value">{duration_min:.1f}<span style="font-size:20px;"> 分钟</span></div>
                <div style="font-size:14px;">≈ {duration_hour:.1f} 小时</div>
            </div>
            <div class="stat-card score-total">
                <div class="label">🏆 综合评分</div>
                <div class="value">{self.scores['total_score']:.1f}<span style="font-size:20px;">/100</span></div>
            </div>
            <div class="stat-card quality-badge">
                <div class="label">💤 睡眠质量</div>
                <div class="value" style="font-size:34px;">{self.sleep_quality}</div>
            </div>
        </div>
'''

        if self.is_critical:
            html_content += f'''
        <div class="alert-critical">
            <h3>⚠️⚠️⚠️ 高度异常警告 ⚠️⚠️⚠️</h3>
            <ul>{"".join(f'<li>❗ {r}</li>' for r in self.critical_reasons)}</ul>
            <p style="margin-top:12px; font-weight:bold;">🚨 建议立即就医检查！</p>
        </div>
'''

        # 温度警告
        if temp_status['low_temp_signal']:
            html_content += f'''
        <div class="temp-warning temp-cold">
            <h3>❄️ 温度过低警告</h3>
            <p>被内温度低于舒适温度5度以上，当前平均温度: {temp_status['current_avg_temp']}℃</p>
            <p>💡 建议增加被褥或适当提高室温</p>
        </div>
'''
        elif temp_status['high_temp_signal']:
            html_content += f'''
        <div class="temp-warning temp-hot">
            <h3>🔥 温度过高警告</h3>
            <p>被内温度高于舒适温度2度以上，当前平均温度: {temp_status['current_avg_temp']}℃</p>
            <p>💡 建议减少被褥或开窗通风</p>
        </div>
'''

        html_content += f'''
        <!-- 温度舒适度状态 -->
        <div class="section">
            <div class="section-title">🌡️ 温度舒适度分析</div>
            <div class="section-content">
                <div class="metrics-row">
                    <div class="metric-box">
                        <div class="metric-label">舒适温度</div>
                        <div class="metric-number">{temp_status['comfort_temp']}℃</div>
                    </div>
                    <div class="metric-box">
                        <div class="metric-label">当前平均温度</div>
                        <div class="metric-number">{temp_status['current_avg_temp']}℃</div>
                    </div>
                    <div class="metric-box">
                        <div class="metric-label">温度状态</div>
                        <div class="metric-number">
                            <span class="temp-badge temp-{temp_status['temp_status']}">
                                {temp_status['temp_status']}
                            </span>
                        </div>
                    </div>
                </div>
                <div style="background:#fafeff; padding:16px; border-radius:20px;">
                    <div>📊 温度阈值说明:</div>
                    <div>• 舒适温度: {temp_status['comfort_temp']}℃</div>
                    <div>• 低温警告: 低于 {temp_status['low_temp_threshold']}℃ (低于舒适温度5度)</div>
                    <div>• 高温警告: 高于 {temp_status['high_temp_threshold']}℃ (高于舒适温度2度)</div>
                    <div>• 持续 {self.config['temp_abnormal_duration']} 秒触发警告</div>
                </div>
            </div>
        </div>

        <!-- 运动检测 -->
        <div class="section">
            <div class="section-title">🏃 第一部分 · 运动检测分析 <span style="font-size:14px; margin-left:20px;">权重 60%</span></div>
            <div class="section-content">
                <div class="metrics-row">
                    <div class="metric-box"><div class="metric-label">🏅 运动得分</div><div class="metric-number">{movement_data['score']}/100</div></div>
                    <div class="metric-box"><div class="metric-label">📊 稳定期占比</div><div class="metric-number">{(movement_data['stable_ratio'] * 100):.1f}%</div></div>
                    <div class="metric-box"><div class="metric-label">⏲️ 监测时长</div><div class="metric-number">{movement_data['duration_minutes']} min</div></div>
                </div>
                <div style="display:flex; flex-wrap:wrap; gap:20px;">
                    <div style="flex:1;">
                        <div style="font-weight:700;">🧠 各部位活动</div>
                        <div>头部: {movement_data['head_activity']}次 | 身体: {movement_data['body_activity']}次 | 手臂: {movement_data['arm_activity']}次</div>
                    </div>
                    <div style="flex:1;">
                        <div style="font-weight:700;">🔄 大幅动作</div>
                        <div>头部偏转: {movement_data['head_turn']}次 | 翻身: {movement_data['body_turn']}次 | 手臂大幅: {movement_data['arm_turn']}次</div>
                    </div>
                </div>
                <hr>
                <div><span style="font-weight:700;">⚡ 活动强度</span><br>
                {"".join(f'<span class="badge-dist">{k}: {v}</span>' for k, v in movement_data['activity_distribution'].items() if v > 0)}
                </div>
            </div>
        </div>

        <!-- 生命体征 -->
        <div class="section">
            <div class="section-title">💓 第二部分 · 生命体征分析 <span style="font-size:14px;">权重 30%</span></div>
            <div class="section-content">
                <div class="metrics-row">
                    <div class="metric-box"><div class="metric-label">❤️ 体征得分</div><div class="metric-number">{self.scores['vital_score']:.0f}/100</div></div>
                    <div class="metric-box"><div class="metric-label">🩸 血氧扣分</div><div class="metric-number">{vital_data['spo2_penalty']}/5</div></div>
                    <div class="metric-box"><div class="metric-label">💓 心率扣分</div><div class="metric-number">{vital_data['hr_penalty']}/5</div></div>
                </div>
                <div style="background:#fafeff; padding:16px; border-radius:20px;">
                    <div>🩸 血氧: 平均 {vital_data['avg_spo2'] or '--'}% | 最低 {vital_data['min_spo2'] if vital_data['min_spo2'] != 100 else '--'}% | 异常 {vital_data['spo2_abnormal_count']}次</div>
                    <div style="margin-top:8px;">💓 心率: 平均 {vital_data['avg_hr'] or '--'}bpm | 最低 {vital_data['min_hr'] if vital_data['min_hr'] != 200 else '--'}bpm | 最高 {vital_data['max_hr'] or '--'}bpm</div>
                    <div style="margin-top:8px;">🌡️ 温度: 被内 {vital_data['avg_temp_inside']:.1f}℃ | 被外 {vital_data['avg_temp_outside']:.1f}℃ | 掀被子: {'是' if vital_data['cover_off_detected'] else '否'}</div>
                </div>
            </div>
        </div>

        <!-- 稳定期 -->
        <div class="section">
            <div class="section-title">😴 第三部分 · 稳定期分析 <span style="font-size:14px;">权重 10%</span></div>
            <div class="section-content">
                <div style="display:flex; gap:24px; flex-wrap:wrap;">
                    <div style="background:#eef2f7; border-radius:30px; padding:18px 28px; text-align:center;">
                        <div style="font-size:28px; font-weight:800;">{(self.stable_ratio * 100):.1f}%</div>
                        <div>稳定期占比</div>
                    </div>
                    <div style="background:#faf2e4; border-radius:30px; padding:18px 28px; text-align:center;">
                        <div style="font-size:28px; font-weight:800;">{self.scores['stable_score']:.0f}/100</div>
                        <div>稳定期得分</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- 汇总 -->
        <div class="section">
            <div class="section-title">📋 综合评分 & 健康建议</div>
            <div class="section-content">
                <div style="background:#eef3fc; border-radius:20px; padding:18px;">
                    <div style="font-weight:700;">📊 评分构成</div>
                    <div>运动 {self.scores['movement_score']:.0f} × 60% = {(self.scores['movement_score'] * 0.6):.1f}</div>
                    <div>生命体征 {self.scores['vital_score']:.0f} × 30% = {(self.scores['vital_score'] * 0.3):.1f}</div>
                    <div>稳定期 {self.scores['stable_score']:.0f} × 10% = {(self.scores['stable_score'] * 0.1):.1f}</div>
                    <div style="border-top:1px solid #ccc; margin-top:10px; padding-top:8px; font-size:18px; font-weight:800;">总分: {self.scores['total_score']:.1f}/100</div>
                </div>
                <div style="background:#eaf5e6; border-radius:20px; padding:18px; margin-top:16px;">
                    <div style="font-weight:700;">💡 健康建议</div>
                    <div>{self._get_advice_text()}</div>
                </div>
            </div>
        </div>

        <div class="footer-note">
            ⚕️ 基于多模态传感器监测数据生成 | 仅供参考，不可替代专业医疗诊断
        </div>
    </div>
</div>
</body>
</html>'''

        # 保存HTML文件
        html_path = filepath.replace('.json', '.html')
        if not html_path.endswith('.html'):
            html_path = filepath + '.html'

        with open(html_path, 'w', encoding='utf-8') as f:
            f.write(html_content)
        print(f"📁 精美HTML报告已保存至: {html_path}")

    def _get_advice_text(self) -> str:
        """生成健康建议文字"""
        if self.is_critical:
            return "🚨 检测到高度异常（血氧/心率异常持续），请立即就医检查！"

        # 温度建议
        temp_status = self.vital.get_temp_status()
        temp_advice = ""
        if temp_status['low_temp_signal']:
            temp_advice = " ❄️ 注意保暖，增加被褥。"
        elif temp_status['high_temp_signal']:
            temp_advice = " 🔥 注意散热，减少被褥。"

        score = self.scores['total_score']
        if score >= 90:
            return f"✅ 睡眠质量优秀，请保持良好作息习惯！{temp_advice}"
        elif score >= 75:
            return f"✅ 睡眠质量良好，建议继续保持规律作息。{temp_advice}"
        elif score >= 60:
            return f"⚠️ 睡眠质量一般，建议减少睡前使用电子设备，保持规律作息。{temp_advice}"
        elif score >= 40:
            return f"⚠️ 睡眠质量较差，建议规律作息、适当运动，改善睡眠环境。{temp_advice}"
        else:
            return f"⚠️ 睡眠质量很差，建议咨询睡眠专科医师。{temp_advice}"

    def reset(self):
        self.movement.reset()
        self.vital.reset()
        self.__init__(self.config)


# ========== 运动检测分析器（帧间累加算法） ==========

class MovementAnalyzer:
    """运动检测分析器 - 使用帧间累加，正确处理跨0°和来回翻转"""

    def __init__(self, config: Dict):
        self.config = config

        self.activity_pairs = {'head': [], 'body': [], 'arm': []}
        self.turn_events = {'head': [], 'body': [], 'arm': []}
        self.current_activity = {'head': None, 'body': None, 'arm': None}
        self.last_quat = {'head': None, 'body': None, 'arm': None}
        self.last_quat_time = {'head': None, 'body': None, 'arm': None}

        self.stats = {
            'start_time': None,
            'end_time': None,
            'total_duration_s': 0,
            'total_weighted_activity': 0.0,
            'total_weighted_turn': 0.0,
            'total_activity_duration': 0.0,
            'head_activity_count': 0,
            'body_activity_count': 0,
            'arm_activity_count': 0,
            'head_turn_count': 0,
            'body_turn_count': 0,
            'arm_turn_count': 0,
            'activity_by_level': {'micro': 0, 'light': 0, 'moderate': 0, 'vigorous': 0, 'extreme': 0},
            'activity_by_duration': {'short': 0, 'medium': 0, 'long': 0, 'very_long': 0},
            'stable_periods': [],
            'high_activity_periods': [],
        }

        self.total_score = 100

    # ========== 四元数处理 ==========

    def _quat_to_euler(self, w: float, x: float, y: float, z: float) -> Tuple[float, float, float]:
        sinr_cosp = 2.0 * (w * x + y * z)
        cosr_cosp = 1.0 - 2.0 * (x * x + y * y)
        roll = math.atan2(sinr_cosp, cosr_cosp)
        sinp = 2.0 * (w * y - z * x)
        sinp = max(-1.0, min(1.0, sinp))
        pitch = math.asin(sinp)
        siny_cosp = 2.0 * (w * z + x * y)
        cosy_cosp = 1.0 - 2.0 * (y * y + z * z)
        yaw = math.atan2(siny_cosp, cosy_cosp)
        return math.degrees(roll), math.degrees(pitch), math.degrees(yaw)

    def _angle_diff(self, a1: float, a2: float) -> float:
        """计算角度差（正确处理360°环绕）"""
        diff = abs(a2 - a1)
        return min(diff, 360 - diff)

    # ========== 时间权重函数（指数衰减） ==========

    def _time_weight(self, duration_seconds: float) -> float:
        cfg = self.config
        if duration_seconds <= cfg['no_impact_duration']:
            return 1.0
        elif duration_seconds <= cfg['mild_impact_duration']:
            ratio = (duration_seconds - cfg['no_impact_duration']) / \
                    (cfg['mild_impact_duration'] - cfg['no_impact_duration'])
            return 1.0 + ratio * 0.2
        elif duration_seconds <= cfg['significant_impact_duration']:
            t = duration_seconds - cfg['mild_impact_duration']
            return 1.2 + (t / 90.0) * 0.45
        else:
            excess = min(duration_seconds, cfg['max_duration']) - cfg['significant_impact_duration']
            exponent = excess / 180.0
            return min(5.0, 1.65 * math.exp(exponent))

    def _recovery_weight(self, recovery_seconds: float) -> float:
        cfg = self.config
        if recovery_seconds <= cfg['fast_recovery']:
            return 1.0
        elif recovery_seconds <= cfg['normal_recovery']:
            ratio = (recovery_seconds - cfg['fast_recovery']) / \
                    (cfg['normal_recovery'] - cfg['fast_recovery'])
            return 1.0 + ratio * 0.3
        elif recovery_seconds <= 120:
            t = recovery_seconds - cfg['normal_recovery']
            return 1.3 + (t / 90.0) * 0.5
        else:
            excess = min(recovery_seconds, cfg['max_recovery']) - 120
            exponent = excess / 120.0
            return min(3.0, 1.8 * math.exp(exponent))

    # ========== 强度权重 ==========

    def _get_intensity_weight(self, intensity_deg: float, sensor_type: str) -> float:
        if sensor_type == 'head':
            if intensity_deg < 3.0:
                return 0.3
            elif intensity_deg < 6.0:
                return 0.5
            elif intensity_deg < 10.0:
                return 0.8
            elif intensity_deg < 15.0:
                return 1.2
            else:
                return 1.8
        elif sensor_type == 'body':
            if intensity_deg < 5.0:
                return 0.2
            elif intensity_deg < 10.0:
                return 0.5
            elif intensity_deg < 20.0:
                return 0.8
            elif intensity_deg < 35.0:
                return 1.3
            else:
                return 2.0
        else:
            if intensity_deg < 8.0:
                return 0.2
            elif intensity_deg < 15.0:
                return 0.4
            elif intensity_deg < 25.0:
                return 0.7
            elif intensity_deg < 40.0:
                return 1.0
            else:
                return 1.5

    def _get_intensity_level(self, intensity_deg: float) -> str:
        if intensity_deg < 3.0:
            return 'micro'
        elif intensity_deg < 6.0:
            return 'light'
        elif intensity_deg < 10.0:
            return 'moderate'
        elif intensity_deg < 20.0:
            return 'vigorous'
        else:
            return 'extreme'

    # ========== 单传感器活动检测（帧间累加） ==========

    def _detect_activity_for_sensor(self, timestamp: float, quat: Tuple,
                                    sensor_type: str, cfg_key_prefix: str):
        cfg = self.config
        activity_threshold = cfg[f'{cfg_key_prefix}_activity_threshold']

        if self.last_quat[sensor_type] is None or self.last_quat_time[sensor_type] is None:
            self.last_quat[sensor_type] = quat
            self.last_quat_time[sensor_type] = timestamp
            return

        angles1 = self._quat_to_euler(*self.last_quat[sensor_type])
        angles2 = self._quat_to_euler(*quat)

        delta_roll = self._angle_diff(angles1[0], angles2[0])
        delta_pitch = self._angle_diff(angles1[1], angles2[1])
        delta_yaw = self._angle_diff(angles1[2], angles2[2])
        frame_intensity = max(delta_roll, delta_pitch, delta_yaw)

        self.last_quat[sensor_type] = quat
        self.last_quat_time[sensor_type] = timestamp

        # 实时打印
        if frame_intensity > 3.0:
            print(f"[{sensor_type.upper()}活动] t={timestamp:.1f}s, 帧变化={frame_intensity:.1f}°")

        if frame_intensity > activity_threshold:
            if self.current_activity[sensor_type] is None:
                # 活动开始
                self.current_activity[sensor_type] = {
                    'start_time': timestamp,
                    'peak_time': timestamp,
                    'max_frame_intensity': frame_intensity,
                    'total_angle_accumulated': 0.0,
                    'last_active_time': timestamp,
                    'sensor_type': sensor_type,
                    'frame_count': 0,
                }
                print(f"[{sensor_type.upper()}活动开始] t={timestamp:.1f}s")
            else:
                # 累加帧间角度变化
                act = self.current_activity[sensor_type]
                act['total_angle_accumulated'] += frame_intensity
                if frame_intensity > act['max_frame_intensity']:
                    act['max_frame_intensity'] = frame_intensity
                    act['peak_time'] = timestamp
                act['frame_count'] += 1
                act['last_active_time'] = timestamp
                act['end_time'] = timestamp
        else:
            if self.current_activity[sensor_type] is not None:
                idle_time = timestamp - self.current_activity[sensor_type]['last_active_time']
                if idle_time > cfg['activity_end_idle_time']:
                    self._finalize_activity_for_sensor(
                        self.current_activity[sensor_type]['last_active_time'], sensor_type
                    )
                    self.current_activity[sensor_type] = None
                else:
                    self.current_activity[sensor_type]['end_time'] = timestamp

    def _finalize_activity_for_sensor(self, end_time: float, sensor_type: str):
        act = self.current_activity[sensor_type]
        if act is None:
            return

        duration = end_time - act['start_time']
        if duration < self.config['min_activity_duration']:
            print(f"[{sensor_type.upper()}活动取消] 时长={duration:.2f}s 太短")
            self.current_activity[sensor_type] = None
            return

        # 使用累加的总角度变化
        total_angle_change = act['total_angle_accumulated']
        effective_intensity = max(act['max_frame_intensity'],
                                  total_angle_change / max(act['frame_count'], 1))

        sensor_weight = self.config[f'{sensor_type}_weight']
        recovery = min(duration * 0.5, self.config['max_recovery'])

        intensity_weight = self._get_intensity_weight(effective_intensity, sensor_type)
        time_weight = self._time_weight(duration)
        recovery_weight = self._recovery_weight(recovery)
        weighted_score = intensity_weight * time_weight * recovery_weight * sensor_weight

        activity_record = {
            'start_time': act['start_time'],
            'end_time': end_time,
            'duration': duration,
            'frame_count': act['frame_count'],
            'total_angle_change': total_angle_change,
            'max_frame_intensity': act['max_frame_intensity'],
            'sensor_type': sensor_type,
            'intensity_level': self._get_intensity_level(effective_intensity),
            'weighted_score': weighted_score,
        }
        self.activity_pairs[sensor_type].append(activity_record)

        self.stats['total_weighted_activity'] += weighted_score
        self.stats['total_activity_duration'] += duration
        self.stats['activity_by_level'][activity_record['intensity_level']] += 1
        self.stats[f'{sensor_type}_activity_count'] += 1

        if duration < 10:
            self.stats['activity_by_duration']['short'] += 1
        elif duration < 60:
            self.stats['activity_by_duration']['medium'] += 1
        elif duration < 300:
            self.stats['activity_by_duration']['long'] += 1
        else:
            self.stats['activity_by_duration']['very_long'] += 1

        # 翻身判断：使用累加总角度
        turn_threshold = self.config[f'{sensor_type}_turn_threshold']
        if total_angle_change >= turn_threshold:
            if total_angle_change < 30:
                angle_weight = 0.6
            elif total_angle_change < 60:
                angle_weight = 1.0
            elif total_angle_change < 90:
                angle_weight = 1.4
            else:
                angle_weight = 1.8

            weighted_score_turn = angle_weight * sensor_weight
            turn_event = {
                'time': act['start_time'],
                'angle': total_angle_change,
                'sensor_type': sensor_type,
                'weighted_score': weighted_score_turn,
            }
            self.turn_events[sensor_type].append(turn_event)
            self.stats['total_weighted_turn'] += weighted_score_turn
            self.stats[f'{sensor_type}_turn_count'] += 1

            action_desc = "头部偏转" if sensor_type == 'head' else "翻身" if sensor_type == 'body' else "手臂大幅动作"
            print(
                f"[{action_desc}] 时间={act['start_time']:.1f}s, 总活动角度={total_angle_change:.1f}°, 加权={weighted_score_turn:.2f}")

        print(
            f"[{sensor_type.upper()}活动记录] 时长={duration:.1f}s, 总角度变化={total_angle_change:.1f}°, 等级={activity_record['intensity_level']}, 加权={weighted_score:.2f}")

        self.current_activity[sensor_type] = None

    # ========== 时段检测 ==========

    def _detect_periods(self, timestamp: float):
        recent_weighted = 0
        for sensor in ['head', 'body', 'arm']:
            for p in self.activity_pairs[sensor]:
                if p['end_time'] > timestamp - 60:
                    recent_weighted += p['weighted_score']

        if recent_weighted < 0.1:
            if not hasattr(self, '_stable_start'):
                self._stable_start = timestamp
        else:
            if hasattr(self, '_stable_start'):
                duration = timestamp - self._stable_start
                if duration >= 10:
                    self.stats['stable_periods'].append({
                        'start': self._stable_start, 'end': timestamp, 'duration': duration,
                    })
                    print(f"[稳定期] 记录一段: {duration:.1f} 秒")
                delattr(self, '_stable_start')

        if recent_weighted > 1.0:
            if not hasattr(self, '_high_start'):
                self._high_start = timestamp
        else:
            if hasattr(self, '_high_start'):
                duration = timestamp - self._high_start
                if duration >= 10:
                    self.stats['high_activity_periods'].append({
                        'start': self._high_start, 'end': timestamp, 'duration': duration,
                    })
                delattr(self, '_high_start')

    # ========== 主接口 ==========

    def add_data(self, timestamp: float, quat_head: Tuple, quat_body: Tuple, quat_arm: Tuple):
        if self.stats['start_time'] is None:
            self.stats['start_time'] = timestamp
            print(f"[睡眠分析] 开始记录，起始时间: {timestamp:.2f} 秒")
            print(f"[传感器分布] BNO0=额头, BNO1=身体, BNO2=手臂")

        self._detect_activity_for_sensor(timestamp, quat_head, 'head', 'head')
        self._detect_activity_for_sensor(timestamp, quat_body, 'body', 'body')
        self._detect_activity_for_sensor(timestamp, quat_arm, 'arm', 'arm')
        self._detect_periods(timestamp)

    def finalize(self, end_time: float):
        for sensor in ['head', 'body', 'arm']:
            if self.current_activity[sensor] is not None:
                self._finalize_activity_for_sensor(end_time, sensor)

        self.stats['end_time'] = end_time
        self.stats['total_duration_s'] = end_time - self.stats['start_time']

        if hasattr(self, '_stable_start'):
            duration = self.stats['end_time'] - self._stable_start
            if duration >= 10:
                self.stats['stable_periods'].append({
                    'start': self._stable_start, 'end': self.stats['end_time'], 'duration': duration,
                })
                print(f"[稳定期] 记录最后一段: {duration:.1f} 秒")
            delattr(self, '_stable_start')

        # 计算运动得分
        duration_hours = self.stats['total_duration_s'] / 3600
        weighted_activity_per_hour = self.stats['total_weighted_activity'] / max(duration_hours, 0.01)

        penalty = min(50, max(0, (weighted_activity_per_hour - 1.0)) * 10)
        self.total_score = max(0, 100 - penalty)

    def get_score(self) -> float:
        return self.total_score

    def get_stable_ratio(self) -> float:
        total_stable = sum(p['duration'] for p in self.stats['stable_periods'])
        return total_stable / max(self.stats['total_duration_s'], 1)

    def get_total_activities(self) -> int:
        return (self.stats['head_activity_count'] +
                self.stats['body_activity_count'] +
                self.stats['arm_activity_count'])

    def print_report(self):
        duration_min = self.stats['total_duration_s'] / 60
        total_stable = sum(p['duration'] for p in self.stats['stable_periods'])
        stable_ratio = total_stable / max(self.stats['total_duration_s'], 1) * 100

        print(f"\n   监测时长: {duration_min:.1f} 分钟")
        print(f"   运动得分: {self.total_score:.1f}/100")
        print(f"   稳定期占比: {stable_ratio:.1f}%")

        print("\n   各部位活动统计:")
        print(f"     头部活动: {self.stats['head_activity_count']} 次")
        print(f"     身体活动: {self.stats['body_activity_count']} 次")
        print(f"     手臂活动: {self.stats['arm_activity_count']} 次")

        print("\n   大幅动作统计:")
        print(f"     头部偏转: {self.stats['head_turn_count']} 次")
        print(f"     身体翻身: {self.stats['body_turn_count']} 次")
        print(f"     手臂大幅动作: {self.stats['arm_turn_count']} 次")

        print("\n   活动强度分布:")
        for level, count in self.stats['activity_by_level'].items():
            if count > 0:
                print(f"     {level}: {count} 次")

    def get_report(self) -> Dict:
        total_stable = sum(p['duration'] for p in self.stats['stable_periods'])
        stable_ratio = total_stable / max(self.stats['total_duration_s'], 1)

        return {
            'duration_minutes': round(self.stats['total_duration_s'] / 60, 1),
            'score': self.total_score,
            'stable_ratio': stable_ratio,
            'head_activity': self.stats['head_activity_count'],
            'body_activity': self.stats['body_activity_count'],
            'arm_activity': self.stats['arm_activity_count'],
            'head_turn': self.stats['head_turn_count'],
            'body_turn': self.stats['body_turn_count'],
            'arm_turn': self.stats['arm_turn_count'],
            'activity_distribution': self.stats['activity_by_level'],
            'activity_by_duration': self.stats['activity_by_duration'],
        }

    def reset(self):
        self.__init__(self.config)


# ========== 生命体征分析器 ==========

class VitalAnalyzer:
    """生命体征分析器"""

    def __init__(self, config: Dict):
        self.config = config

        self.spo2_abnormal_count = 0
        self.hr_abnormal_count = 0
        self.spo2_penalty = 0
        self.hr_penalty = 0
        self.temp_penalty = 0

        self.avg_spo2 = 0
        self.min_spo2 = 100
        self.avg_hr = 0
        self.min_hr = 200
        self.max_hr = 0
        self.avg_temp_inside = 0
        self.avg_temp_outside = 0
        self.cover_off_detected = False

        self.is_critical = False
        self.critical_reasons = []

        self.spo2_values = []
        self.hr_values = []
        self.temp_inside_values = []
        self.temp_outside_values = []

        self._current_spo2_start = None
        self._current_hr_start = None
        self._temp_start = None
        self._temp_triggered = False

        # ========== 新增：温度舒适度判断 ==========
        self.comfort_temp = config.get('comfort_temp', 34.0)  # 舒适温度34°C
        self.low_temp_threshold = self.comfort_temp - config.get('low_temp_offset', 5.0)  # 29°C
        self.high_temp_threshold = self.comfort_temp + config.get('high_temp_offset', 2.0)  # 36°C
        self.temp_abnormal_duration = config.get('temp_abnormal_duration', 120)  # 2分钟

        self.low_temp_start = None  # 低温开始时间
        self.high_temp_start = None  # 高温开始时间
        self.low_temp_signal = False  # 低温信号
        self.high_temp_signal = False  # 高温信号
        self.temp_status = "正常"  # 温度状态：正常/过低/过高

        self.stats = {}
        self._total_score = 100

    def add_data(self, timestamp, spo2=None, hr=None, temp_inside=None, temp_outside=None):
        # 血氧
        if spo2 and 0 < spo2 <= 100:
            self.spo2_values.append(spo2)
            self.min_spo2 = min(self.min_spo2, spo2)

            if spo2 < self.config['spo2_normal_min']:
                if self._current_spo2_start is None:
                    self._current_spo2_start = timestamp
                else:
                    duration = timestamp - self._current_spo2_start
                    if duration >= self.config['critical_duration']:
                        self.is_critical = True
                        self.critical_reasons.append(f"血氧持续异常{duration:.0f}秒")
            else:
                if self._current_spo2_start is not None:
                    duration = timestamp - self._current_spo2_start
                    if duration >= self.config['abnormal_min_duration']:
                        self.spo2_abnormal_count += 1
                        self.spo2_penalty = min(self.config['max_spo2_penalty'],
                                                self.spo2_penalty + 1)
                    self._current_spo2_start = None

        # 心率
        if hr and 0 < hr < 200:
            self.hr_values.append(hr)
            self.min_hr = min(self.min_hr, hr)
            self.max_hr = max(self.max_hr, hr)

            if hr < self.config['hr_normal_min'] or hr > self.config['hr_normal_max']:
                if self._current_hr_start is None:
                    self._current_hr_start = timestamp
                else:
                    duration = timestamp - self._current_hr_start
                    if duration >= self.config['critical_duration']:
                        self.is_critical = True
                        self.critical_reasons.append(f"心率持续异常{duration:.0f}秒")
            else:
                if self._current_hr_start is not None:
                    duration = timestamp - self._current_hr_start
                    if duration >= self.config['abnormal_min_duration']:
                        self.hr_abnormal_count += 1
                        self.hr_penalty = min(self.config['max_hr_penalty'],
                                              self.hr_penalty + 1)
                    self._current_hr_start = None

        # 温度处理（带舒适度判断）
        if temp_inside is not None and temp_outside is not None:
            self.temp_inside_values.append(temp_inside)
            self.temp_outside_values.append(temp_outside)
            temp_diff = temp_inside - temp_outside

            # 原有：掀被子检测
            if not self._temp_triggered and temp_diff < self.config['temp_diff_threshold']:
                if self._temp_start is None:
                    self._temp_start = timestamp
                else:
                    duration = timestamp - self._temp_start
                    if duration >= self.config['cover_off_min_duration']:
                        self.cover_off_detected = True
                        self.temp_penalty = self.config['temp_penalty']
                        self._temp_triggered = True
            else:
                self._temp_start = None

            # ========== 新增：温度舒适度判断 ==========
            # 低温判断（低于舒适温度5度）
            if temp_inside <= self.low_temp_threshold:
                if self.low_temp_start is None:
                    self.low_temp_start = timestamp
                    print(f"[温度警告] 检测到低温: {temp_inside:.1f}℃ (低于{self.low_temp_threshold}℃)")
                else:
                    duration = timestamp - self.low_temp_start
                    if duration >= self.temp_abnormal_duration and not self.low_temp_signal:
                        self.low_temp_signal = True
                        self.temp_status = "过低"
                        self.critical_reasons.append(f"被内温度过低({temp_inside:.1f}℃)持续{duration:.0f}秒")
                        print(f"[温度警告] ❄️ 温度过低！持续{duration:.0f}秒，当前温度{temp_inside:.1f}℃")
            else:
                if self.low_temp_start is not None:
                    duration = timestamp - self.low_temp_start
                    if duration >= self.temp_abnormal_duration:
                        print(f"[温度恢复] 低温已恢复，共持续{duration:.0f}秒")
                    self.low_temp_start = None

            # 高温判断（高于舒适温度2度）
            if temp_inside >= self.high_temp_threshold:
                if self.high_temp_start is None:
                    self.high_temp_start = timestamp
                    print(f"[温度警告] 检测到高温: {temp_inside:.1f}℃ (高于{self.high_temp_threshold}℃)")
                else:
                    duration = timestamp - self.high_temp_start
                    if duration >= self.temp_abnormal_duration and not self.high_temp_signal:
                        self.high_temp_signal = True
                        self.temp_status = "过高"
                        self.critical_reasons.append(f"被内温度过高({temp_inside:.1f}℃)持续{duration:.0f}秒")
                        print(f"[温度警告] 🔥 温度过高！持续{duration:.0f}秒，当前温度{temp_inside:.1f}℃")
            else:
                if self.high_temp_start is not None:
                    duration = timestamp - self.high_temp_start
                    if duration >= self.temp_abnormal_duration:
                        print(f"[温度恢复] 高温已恢复，共持续{duration:.0f}秒")
                    self.high_temp_start = None

    def finalize(self, end_time):
        if self.spo2_values:
            self.avg_spo2 = sum(self.spo2_values) / len(self.spo2_values)
        if self.hr_values:
            self.avg_hr = sum(self.hr_values) / len(self.hr_values)
        if self.temp_inside_values:
            self.avg_temp_inside = sum(self.temp_inside_values) / len(self.temp_inside_values)
        if self.temp_outside_values:
            self.avg_temp_outside = sum(self.temp_outside_values) / len(self.temp_outside_values)

        total_penalty = self.spo2_penalty + self.hr_penalty + self.temp_penalty
        self._total_score = max(0, 100 - total_penalty)

        self.stats = {
            'avg_spo2': round(self.avg_spo2, 1),
            'min_spo2': round(self.min_spo2, 1),
            'spo2_abnormal_count': self.spo2_abnormal_count,
            'spo2_penalty': self.spo2_penalty,
            'avg_hr': round(self.avg_hr),
            'min_hr': self.min_hr,
            'max_hr': self.max_hr,
            'hr_abnormal_count': self.hr_abnormal_count,
            'hr_penalty': self.hr_penalty,
            'avg_temp_inside': round(self.avg_temp_inside, 1),
            'avg_temp_outside': round(self.avg_temp_outside, 1),
            'cover_off_detected': self.cover_off_detected,
            'temp_penalty': self.temp_penalty,
        }

        # 输出温度状态总结
        if self.low_temp_signal:
            print(f"[温度总结] ⚠️ 本次睡眠存在低温情况，最低{min(self.temp_inside_values):.1f}℃")
        if self.high_temp_signal:
            print(f"[温度总结] ⚠️ 本次睡眠存在高温情况，最高{max(self.temp_inside_values):.1f}℃")
        if not self.low_temp_signal and not self.high_temp_signal and self.temp_inside_values:
            print(f"[温度总结] ✅ 温度舒适，平均{self.avg_temp_inside:.1f}℃")

    def get_score(self) -> float:
        return self._total_score

    def get_stats(self) -> Dict:
        return self.stats

    def get_temp_status(self) -> Dict:
        """获取温度舒适度状态"""
        return {
            'comfort_temp': self.comfort_temp,
            'low_temp_threshold': self.low_temp_threshold,
            'high_temp_threshold': self.high_temp_threshold,
            'low_temp_signal': self.low_temp_signal,
            'high_temp_signal': self.high_temp_signal,
            'temp_status': self.temp_status,
            'current_avg_temp': round(self.avg_temp_inside, 1) if self.temp_inside_values else None
        }

    def print_report(self):
        print(f"\n   生命体征得分: {self._total_score:.1f}/100")

        print("\n   血氧分析:")
        print(f"     平均血氧: {self.avg_spo2:.1f}%")
        print(f"     最低血氧: {self.min_spo2:.1f}%")
        print(f"     异常事件: {self.spo2_abnormal_count} 次")
        print(f"     累计扣分: {self.spo2_penalty}/5")

        print("\n   心率分析:")
        print(f"     平均心率: {self.avg_hr:.0f} bpm")
        print(f"     最低心率: {self.min_hr:.0f} bpm")
        print(f"     最高心率: {self.max_hr:.0f} bpm")
        print(f"     异常事件: {self.hr_abnormal_count} 次")
        print(f"     累计扣分: {self.hr_penalty}/5")

        print("\n   温度分析:")
        print(f"     被内温度: {self.avg_temp_inside:.1f}℃")
        print(f"     被外温度: {self.avg_temp_outside:.1f}℃")
        if self.cover_off_detected:
            print(f"     掀被子检测: 是 (扣{self.temp_penalty}分)")
        else:
            print(f"     掀被子检测: 否")

        # 新增温度舒适度输出
        print("\n   温度舒适度:")
        print(f"     舒适温度: {self.comfort_temp}℃")
        print(f"     温度状态: {self.temp_status}")
        if self.low_temp_signal:
            print(f"     ⚠️ 检测到低温！建议增加被褥")
        if self.high_temp_signal:
            print(f"     ⚠️ 检测到高温！建议减少被褥或开窗通风")

    def get_report(self) -> Dict:
        return self.stats

    def reset(self):
        self.__init__(self.config)