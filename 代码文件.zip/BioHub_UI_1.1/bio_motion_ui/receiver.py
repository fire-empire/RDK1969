import struct
import threading
import time
from collections import deque
from typing import Deque, List, Optional, Tuple

import serial
from serial.tools import list_ports
from PyQt5 import QtCore

from .config import NETWORK, PROTOCOL, SENSORS
from .models import RxStats, Sample
from .protocol import (
    AD_SAMPLE_SIZE,
    AD_SAMPLE_STRUCT,
    BLUETOOTH_MAGIC_BYTES,
    CRC_SIZE,
    CRC_STRUCT,
    HEART_PAYLOAD_SIZE,
    HEART_STRUCT,
    REDUNDANT_HEADER_SIZE,
    REDUNDANT_HEADER_STRUCT,
    SENSOR_PAYLOAD_SIZE,
    TEMP_STRUCT,
)


class BluetoothReceiverThread(QtCore.QThread):
    """High-priority Bluetooth SPP receiver and packet parser."""

    def __init__(
        self,
        serial_port: str,
        baudrate: int,
        device_name: str,
        buffer_maxlen: int = 60000,
    ):
        super().__init__()
        self.serial_port = serial_port
        self.baudrate = baudrate
        self.device_name = device_name

        self._stop_event = threading.Event()
        self._lock = threading.Lock()
        self._samples: Deque[Sample] = deque(maxlen=buffer_maxlen)
        self._stats = RxStats()
        self._latest_quat: Tuple[Tuple[float, float, float, float], ...] = tuple(
            (0.0, 0.0, 0.0, 0.0) for _ in range(SENSORS.bno_count)
        )
        self._latest_max30102 = (0, 0, 0)
        self._latest_temperature: Tuple[Optional[float], Optional[float]] = (None, None)

        self._highest_seq = 0
        self._next_loss_seq = 0
        self._seq_tracker_ready = False
        self._seen_seq = set()
        self._highest_ad_seq = 0
        self._next_ad_loss_seq = 0
        self._ad_tracker_ready = False
        self._seen_ad_seq = set()
        self._rx_stream = bytearray()

        self._heart_lock = threading.Lock()
        self._heart_samples: Deque[Tuple[int, int, int]] = deque(
            maxlen=SENSORS.heart_queue_maxlen
        )
        self._last_heart_time_ms = 0
        self._auto_port_index = 0

    @staticmethod
    def describe_ports() -> List[str]:
        ports = []
        for port in list_ports.comports():
            fields = [
                port.device,
                port.description,
                port.manufacturer,
                port.product,
                port.hwid,
            ]
            ports.append(" | ".join(field for field in fields if field))
        return ports

    @staticmethod
    def _port_search_text(port) -> str:
        fields = [
            port.device,
            port.name,
            port.description,
            port.manufacturer,
            port.product,
            port.hwid,
        ]
        return " ".join(field for field in fields if field).lower()

    @classmethod
    def _is_bluetooth_port(cls, port) -> bool:
        text = cls._port_search_text(port)
        return (
            "bluetooth" in text
            or "蓝牙" in text
            or "bthenum" in text
            or "rfcomm" in text
            or "{00001101-0000-1000-8000-00805f9b34fb}" in text
        )

    @classmethod
    def _port_score(cls, port, device_name: str) -> int:
        text = cls._port_search_text(port)
        score = 0
        if device_name and device_name in text:
            score += 100
        if cls._is_bluetooth_port(port):
            score += 30
        if "{00001101-0000-1000-8000-00805f9b34fb}" in text:
            score += 10
        if "localmfg" in text:
            score -= 25
        else:
            score += 20
        return score

    def _candidate_serial_ports(self) -> List[str]:
        # +++ 添加这 4 行 +++
        import os
        if os.path.exists("/dev/rfcomm0"):
            return ["/dev/rfcomm0"]
        # +++ 添加结束 +++
        device_name = self.device_name.lower()
        scored = []
        for port in list_ports.comports():
            text = self._port_search_text(port)
            if not self._is_bluetooth_port(port) and (
                not device_name or device_name not in text
            ):
                continue
            scored.append((self._port_score(port, device_name), port.device))

        scored.sort(key=lambda item: (-item[0], item[1]))
        return [device for _, device in scored]

    @classmethod
    def port_choices(cls, device_name: str) -> List[Tuple[str, str, bool]]:
        scored = []
        fallback = []
        device_name_lc = device_name.lower()

        for port in list_ports.comports():
            fields = [
                port.device,
                port.description,
                port.manufacturer,
                port.product,
            ]
            label = " | ".join(field for field in fields if field)
            is_bluetooth = cls._is_bluetooth_port(port)
            text = cls._port_search_text(port)
            name_matches = bool(device_name_lc and device_name_lc in text)
            if is_bluetooth or name_matches:
                scored.append((cls._port_score(port, device_name_lc), port.device, label))
            else:
                fallback.append((port.device, label))

        scored.sort(key=lambda item: (-item[0], item[1]))
        fallback.sort(key=lambda item: item[0])
        return (
            [(device, label, True) for _, device, label in scored]
            + [(device, label, False) for device, label in fallback]
        )

    def probe_ports(self, seconds_per_port: float = 2.0) -> List[str]:
        original_serial_port = self.serial_port
        results = []
        candidates = [original_serial_port] if original_serial_port else self._candidate_serial_ports()
        if not candidates:
            return ["No bluetooth serial candidates found."]

        for port in candidates:
            ser = None
            try:
                ser = serial.Serial(
                    port=port,
                    baudrate=self.baudrate,
                    timeout=NETWORK.serial_timeout_s,
                    write_timeout=0,
                )
                ser.reset_input_buffer()
                deadline = time.monotonic() + seconds_per_port
                total = 0
                valid_samples = 0
                invalid_before = self._stats.invalid_count
                self._rx_stream.clear()

                while time.monotonic() < deadline:
                    chunk = ser.read(NETWORK.serial_read_bytes)
                    if not chunk:
                        continue
                    total += len(chunk)
                    self._rx_stream.extend(chunk)
                    valid_samples += len(self._drain_stream())
                    if valid_samples > 0:
                        break

                invalid_delta = self._stats.invalid_count - invalid_before
                results.append(
                    f"{port}: bytes={total} valid_samples={valid_samples} invalid={invalid_delta}"
                )
            except Exception as exc:
                results.append(f"{port}: open/read failed: {exc}")
            finally:
                self._rx_stream.clear()
                if ser is not None:
                    try:
                        ser.close()
                    except Exception:
                        pass

        return results

    def _resolve_serial_port(self) -> str:
        # +++ 添加这 4 行 +++
        import os
        if os.path.exists("/dev/rfcomm0"):
            return ["/dev/rfcomm0"]
        # +++ 添加结束 +++
        if self.serial_port:
            return self.serial_port

        candidates = self._candidate_serial_ports()
        if candidates:
            port = candidates[self._auto_port_index % len(candidates)]
            self._auto_port_index += 1
            return port

        available = "; ".join(self.describe_ports()) or "none"
        raise RuntimeError(
            f"No bluetooth COM port found. Pair {self.device_name}, or pass --bt-port. "
            f"Available ports: {available}"
        )

    def stop(self) -> None:
        self._stop_event.set()

    def pop_all_samples(self, max_items: Optional[int] = None) -> List[Sample]:
        with self._lock:
            if not self._samples:
                return []
            if max_items is not None and len(self._samples) > max_items:
                out = list(self._samples)[-max_items:]
            else:
                out = list(self._samples)
            self._samples.clear()
            return out

    def pop_heart_samples(self) -> List[Tuple[int, int, int]]:
        with self._heart_lock:
            if not self._heart_samples:
                return []
            out = list(self._heart_samples)
            self._heart_samples.clear()
            return out

    def get_stats(self) -> RxStats:
        with self._lock:
            s = self._stats
            return RxStats(
                packet_count=s.packet_count,
                rx_bytes=s.rx_bytes,
                invalid_count=s.invalid_count,
                lost_count=s.lost_count,
                duplicate_count=s.duplicate_count,
                out_of_order_count=s.out_of_order_count,
                late_count=s.late_count,
                ad_lost_count=s.ad_lost_count,
                ad_duplicate_count=s.ad_duplicate_count,
                ad_recovered_count=s.ad_recovered_count,
                dropped_in_buffer=s.dropped_in_buffer,
                last_seq=s.last_seq,
                has_last_seq=s.has_last_seq,
                transport_connected=s.transport_connected,
                last_error=s.last_error,
            )

    def _set_transport_state(self, connected: bool, error: str = "") -> None:
        with self._lock:
            self._stats.transport_connected = connected
            self._stats.last_error = error[:180]

    def _add_rx_bytes(self, count: int) -> None:
        with self._lock:
            self._stats.rx_bytes += count

    @staticmethod
    def _seq_distance(newer: int, older: int) -> int:
        return (newer - older) & 0xFFFFFFFF

    @staticmethod
    def _seq_is_ahead(candidate: int, reference: int) -> bool:
        delta = (candidate - reference) & 0xFFFFFFFF
        return 0 < delta < 0x80000000

    @staticmethod
    def _crc16_ccitt(data: bytes) -> int:
        crc = PROTOCOL.crc16_init
        for value in data:
            crc ^= value << 8
            for _ in range(8):
                if crc & 0x8000:
                    crc = ((crc << 1) ^ 0x1021) & 0xFFFF
                else:
                    crc = (crc << 1) & 0xFFFF
        return crc

    def _finalize_loss_window(self) -> None:
        while self._seq_distance(self._highest_seq, self._next_loss_seq) > PROTOCOL.reorder_window_packets:
            if self._next_loss_seq not in self._seen_seq:
                self._stats.lost_count += 1
            else:
                self._seen_seq.discard(self._next_loss_seq)
            self._next_loss_seq = (self._next_loss_seq + 1) & 0xFFFFFFFF

    def _accept_sequence(self, seq: int) -> bool:
        self._stats.packet_count += 1

        if not self._seq_tracker_ready:
            self._seq_tracker_ready = True
            self._highest_seq = seq
            self._next_loss_seq = seq
            self._seen_seq.add(seq)
            self._stats.last_seq = seq
            self._stats.has_last_seq = True
            return True

        if seq in self._seen_seq:
            self._stats.duplicate_count += 1
            return False

        if self._seq_is_ahead(seq, self._highest_seq):
            self._highest_seq = seq
            self._seen_seq.add(seq)
            self._stats.last_seq = self._highest_seq
            self._finalize_loss_window()
            return True

        back_distance = self._seq_distance(self._highest_seq, seq)
        self._stats.out_of_order_count += 1
        if back_distance > PROTOCOL.reorder_window_packets:
            self._stats.late_count += 1
            return False

        self._seen_seq.add(seq)
        return True

    def _finalize_ad_loss_window(self) -> None:
        while self._seq_distance(self._highest_ad_seq, self._next_ad_loss_seq) > PROTOCOL.reorder_window_packets:
            if self._next_ad_loss_seq not in self._seen_ad_seq:
                self._stats.ad_lost_count += 1
            else:
                self._seen_ad_seq.discard(self._next_ad_loss_seq)
            self._next_ad_loss_seq = (self._next_ad_loss_seq + 1) & 0xFFFFFFFF

    def _accept_ad_sample(self, seq: int) -> bool:
        if not self._ad_tracker_ready:
            self._ad_tracker_ready = True
            self._highest_ad_seq = seq
            self._next_ad_loss_seq = seq
            self._seen_ad_seq.add(seq)
            return True

        if seq in self._seen_ad_seq:
            self._stats.ad_duplicate_count += 1
            return False

        if self._seq_is_ahead(seq, self._highest_ad_seq):
            self._highest_ad_seq = seq
            self._seen_ad_seq.add(seq)
            self._finalize_ad_loss_window()
            return True

        back_distance = self._seq_distance(self._highest_ad_seq, seq)
        if back_distance > PROTOCOL.reorder_window_packets:
            return False

        self._seen_ad_seq.add(seq)
        self._stats.ad_recovered_count += 1
        return False

    def _queue_heart_sample_if_new(self, red: int, ir: int, sample_time_ms: int) -> None:
        if sample_time_ms <= 0 or sample_time_ms == self._last_heart_time_ms:
            return

        self._last_heart_time_ms = sample_time_ms
        with self._heart_lock:
            self._heart_samples.append((red, ir, sample_time_ms))

    def _sample_from_ad_tuple(self, unpacked, slow_update: bool = False) -> Optional[Sample]:
        sample_seq = unpacked[0]
        if not self._accept_ad_sample(sample_seq):
            return None

        max30102_red, max30102_ir, max30102_time_ms = self._latest_max30102
        return Sample(
            ts_s=unpacked[1] * 1e-6,
            ad=unpacked[2:],
            quat=self._latest_quat,
            max30102_red=max30102_red,
            max30102_ir=max30102_ir,
            max30102_time_ms=max30102_time_ms,
            temperature_c=self._latest_temperature,
            slow_update=slow_update,
        )

    def _parse_bluetooth_payload(self, payload: bytes) -> List[Sample]:
        out: List[Sample] = []
        magic, version, packet_type, packet_seq, sample_count = (
            REDUNDANT_HEADER_STRUCT.unpack_from(payload, 0)
        )

        if (
            magic != PROTOCOL.redundant_magic
            or version != PROTOCOL.redundant_version
            or sample_count == 0
            or sample_count > PROTOCOL.ad_redundancy
        ):
            self._stats.invalid_count += 1
            return out

        valid_packet_types = (
            PROTOCOL.redundant_type_ad,
            PROTOCOL.redundant_type_full,
            PROTOCOL.redundant_type_heart,
        )
        if packet_type not in valid_packet_types:
            self._stats.invalid_count += 1
            return out

        if not self._accept_sequence(packet_seq):
            return out

        if packet_type == PROTOCOL.redundant_type_full:
            sensor_offset = REDUNDANT_HEADER_SIZE + sample_count * AD_SAMPLE_SIZE
            q12 = struct.unpack_from("<12f", payload, sensor_offset)
            self._latest_quat = (
                (q12[0], q12[1], q12[2], q12[3]),
                (q12[4], q12[5], q12[6], q12[7]),
                (q12[8], q12[9], q12[10], q12[11]),
            )
            heart_offset = sensor_offset + struct.calcsize("<12f")
            self._latest_max30102 = HEART_STRUCT.unpack_from(payload, heart_offset)
            temp_offset = heart_offset + struct.calcsize("<III")
            self._latest_temperature = TEMP_STRUCT.unpack_from(payload, temp_offset)
            self._queue_heart_sample_if_new(*self._latest_max30102)
        elif packet_type == PROTOCOL.redundant_type_heart:
            heart_offset = REDUNDANT_HEADER_SIZE + sample_count * AD_SAMPLE_SIZE
            self._latest_max30102 = HEART_STRUCT.unpack_from(payload, heart_offset)
            self._queue_heart_sample_if_new(*self._latest_max30102)

        for i in range(sample_count):
            sample_offset = REDUNDANT_HEADER_SIZE + i * AD_SAMPLE_SIZE
            sample_tuple = AD_SAMPLE_STRUCT.unpack_from(payload, sample_offset)
            sample = self._sample_from_ad_tuple(
                sample_tuple,
                slow_update=packet_type == PROTOCOL.redundant_type_full
                and i == sample_count - 1,
            )
            if sample is not None:
                out.append(sample)

        return out

    def _drain_stream(self) -> List[Sample]:
        out: List[Sample] = []

        while len(self._rx_stream) >= REDUNDANT_HEADER_SIZE + CRC_SIZE:
            magic_pos = self._rx_stream.find(BLUETOOTH_MAGIC_BYTES)
            if magic_pos < 0:
                keep_last = self._rx_stream[-1:] == BLUETOOTH_MAGIC_BYTES[:1]
                self._stats.invalid_count += max(0, len(self._rx_stream) - int(keep_last))
                self._rx_stream[:] = self._rx_stream[-1:] if keep_last else b""
                break

            if magic_pos > 0:
                self._stats.invalid_count += magic_pos
                del self._rx_stream[:magic_pos]

            if len(self._rx_stream) < REDUNDANT_HEADER_SIZE:
                break

            _, version, packet_type, _, sample_count = REDUNDANT_HEADER_STRUCT.unpack_from(
                self._rx_stream, 0
            )
            valid_packet_types = (
                PROTOCOL.redundant_type_ad,
                PROTOCOL.redundant_type_full,
                PROTOCOL.redundant_type_heart,
            )
            if (
                version != PROTOCOL.redundant_version
                or sample_count == 0
                or sample_count > PROTOCOL.ad_redundancy
                or packet_type not in valid_packet_types
            ):
                self._stats.invalid_count += 1
                del self._rx_stream[0]
                continue

            payload_size = REDUNDANT_HEADER_SIZE + sample_count * AD_SAMPLE_SIZE
            if packet_type == PROTOCOL.redundant_type_full:
                payload_size += SENSOR_PAYLOAD_SIZE
            elif packet_type == PROTOCOL.redundant_type_heart:
                payload_size += HEART_PAYLOAD_SIZE
            frame_size = payload_size + CRC_SIZE

            if len(self._rx_stream) < frame_size:
                break

            payload = bytes(self._rx_stream[:payload_size])
            expected_crc = CRC_STRUCT.unpack_from(self._rx_stream, payload_size)[0]
            actual_crc = self._crc16_ccitt(payload)
            if expected_crc != actual_crc:
                self._stats.invalid_count += 1
                del self._rx_stream[0]
                continue

            del self._rx_stream[:frame_size]
            parsed = self._parse_bluetooth_payload(payload)
            if parsed:
                out.extend(parsed)
                if len(out) >= NETWORK.rx_batch_max:
                    break

        return out

    def _open_serial(self) -> serial.Serial:
        port = self._resolve_serial_port()
        ser = serial.Serial(
            port=port,
            baudrate=self.baudrate,
            timeout=NETWORK.serial_timeout_s,
            write_timeout=0,
        )
        try:
            ser.set_buffer_size(rx_size=NETWORK.serial_rx_buffer)
        except (AttributeError, OSError, ValueError):
            pass
        ser.reset_input_buffer()
        return ser

    def run(self) -> None:
        while not self._stop_event.is_set():
            ser = None
            try:
                ser = self._open_serial()
                self._rx_stream.clear()
                self._set_transport_state(True, f"connected {ser.port}, waiting data")
                last_rx_s = time.monotonic()

                while not self._stop_event.is_set():
                    chunk = ser.read(NETWORK.serial_read_bytes)
                    if not chunk:
                        if (
                            not self.serial_port
                            and time.monotonic() - last_rx_s >= NETWORK.serial_idle_reopen_s
                        ):
                            raise TimeoutError(
                                f"{ser.port} no data, trying next bluetooth COM port"
                            )
                        continue

                    last_rx_s = time.monotonic()
                    self._set_transport_state(True, f"receiving {ser.port}")
                    self._add_rx_bytes(len(chunk))
                    self._rx_stream.extend(chunk)
                    batch = self._drain_stream()
                    if not batch:
                        continue

                    if len(batch) > 1:
                        batch.sort(key=lambda sample: sample.ts_s)
                    with self._lock:
                        overflow = max(0, len(self._samples) + len(batch) - self._samples.maxlen)
                        self._stats.dropped_in_buffer += overflow
                        self._samples.extend(batch)
            except TimeoutError as exc:
                self._set_transport_state(False, str(exc))
                if self.serial_port:
                    time.sleep(NETWORK.serial_reconnect_s)
            except Exception as exc:
                self._set_transport_state(False, str(exc))
                time.sleep(NETWORK.serial_reconnect_s)
            finally:
                if ser is not None:
                    try:
                        ser.close()
                    except Exception:
                        pass

        self._set_transport_state(False, "")


UdpReceiverThread = BluetoothReceiverThread
