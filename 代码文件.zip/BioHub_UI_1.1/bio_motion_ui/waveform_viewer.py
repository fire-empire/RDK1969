#!/usr/bin/env python3
"""
实时波形显示窗口 - 显示三个传感器的连续角度变化曲线
"""

import math
from collections import deque
from typing import Optional

import numpy as np
import pyqtgraph as pg
from PyQt5 import QtCore, QtWidgets


class WaveformViewer(QtWidgets.QMainWindow):
    """实时波形显示窗口 - 三传感器连续曲线"""

    def __init__(self, max_points: int = 500):
        super().__init__()
        self.setWindowTitle("传感器实时波形监控 - 三轴角度变化")
        self.resize(1400, 900)

        # 数据缓存
        self.max_points = max_points
        self.time_buf = deque(maxlen=max_points)

        # BNO0 (额头/手腕) 数据
        self.head_roll_buf = deque(maxlen=max_points)
        self.head_pitch_buf = deque(maxlen=max_points)
        self.head_yaw_buf = deque(maxlen=max_points)

        # BNO1 (身体/腰部) 数据
        self.body_roll_buf = deque(maxlen=max_points)
        self.body_pitch_buf = deque(maxlen=max_points)
        self.body_yaw_buf = deque(maxlen=max_points)

        # BNO2 (手臂) 数据
        self.arm_roll_buf = deque(maxlen=max_points)
        self.arm_pitch_buf = deque(maxlen=max_points)
        self.arm_yaw_buf = deque(maxlen=max_points)

        # 活动强度
        self.activity_intensity_buf = deque(maxlen=max_points)

        self.base_time = None
        self._frozen = False

        self._setup_ui()  # 这里已经创建了所有标签页
        # 不需要再调用 _setup_plots()

        # 定时器更新图表 (30fps)
        self.update_timer = QtCore.QTimer()
        self.update_timer.timeout.connect(self._update_plots)
        self.update_timer.start(33)

    def _setup_ui(self):
        """设置界面"""
        central = QtWidgets.QWidget()
        self.setCentralWidget(central)
        layout = QtWidgets.QVBoxLayout(central)

        # 控制栏
        control_bar = QtWidgets.QHBoxLayout()

        self.clear_btn = QtWidgets.QPushButton("清空波形")
        self.clear_btn.clicked.connect(self._clear_buffers)
        control_bar.addWidget(self.clear_btn)

        self.freeze_btn = QtWidgets.QPushButton("冻结")
        self.freeze_btn.setCheckable(True)
        self.freeze_btn.toggled.connect(self._toggle_freeze)
        control_bar.addWidget(self.freeze_btn)

        control_bar.addStretch()

        self.status_label = QtWidgets.QLabel("等待数据...")
        control_bar.addWidget(self.status_label)

        layout.addLayout(control_bar)

        # 使用 TabWidget 组织三个传感器
        self.tab_widget = QtWidgets.QTabWidget()
        layout.addWidget(self.tab_widget)

        # 活动强度标签页
        self._setup_activity_tab()

        # BNO0 标签页
        self._setup_head_tab()

        # BNO1 标签页
        self._setup_body_tab()

        # BNO2 标签页
        self._setup_arm_tab()

    def _setup_activity_tab(self):
        """设置活动强度标签页"""
        tab = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(tab)

        self.activity_plot = pg.PlotWidget()
        self.activity_plot.setBackground("#1a1a2e")
        self.activity_plot.showGrid(x=True, y=True, alpha=0.3)
        self.activity_plot.setLabel("left", "活动强度", units="度/帧")
        self.activity_plot.setLabel("bottom", "时间", units="秒")
        self.activity_plot.setTitle("📊 综合活动强度（帧间角度变化）")
        self.activity_plot.setYRange(0, 50, padding=0.0)

        self.activity_curve = self.activity_plot.plot(
            pen=pg.mkPen("#ff6b6b", width=2), name="活动强度"
        )

        # 添加阈值线
        threshold_line = pg.InfiniteLine(pos=5, angle=0,
                                         pen=pg.mkPen("#f9ca24", width=1, style=QtCore.Qt.DashLine))
        self.activity_plot.addItem(threshold_line)

        layout.addWidget(self.activity_plot)
        self.tab_widget.addTab(tab, "📊 活动强度")

    def _setup_head_tab(self):
        """设置 BNO0 (额头) 标签页"""
        tab = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(tab)

        self.head_plot = pg.PlotWidget()
        self.head_plot.setBackground("#1a1a2e")
        self.head_plot.showGrid(x=True, y=True, alpha=0.3)
        self.head_plot.setLabel("left", "角度", units="度")
        self.head_plot.setLabel("bottom", "时间", units="秒")
        self.head_plot.setTitle("👤 BNO0 (额头/手腕) - 连续角度变化")
        self.head_plot.setYRange(-180, 180, padding=0.0)
        self.head_plot.addLegend()

        self.head_roll_curve = self.head_plot.plot(
            pen=pg.mkPen("#ff4757", width=2), name="Roll (左右倾斜)")
        self.head_pitch_curve = self.head_plot.plot(
            pen=pg.mkPen("#2ed573", width=2), name="Pitch (前后俯仰)")
        self.head_yaw_curve = self.head_plot.plot(
            pen=pg.mkPen("#70a1ff", width=2), name="Yaw (左右转头)")

        layout.addWidget(self.head_plot)
        self.tab_widget.addTab(tab, "👤 BNO0 (额头)")

    def _setup_body_tab(self):
        """设置 BNO1 (身体) 标签页"""
        tab = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(tab)

        self.body_plot = pg.PlotWidget()
        self.body_plot.setBackground("#1a1a2e")
        self.body_plot.showGrid(x=True, y=True, alpha=0.3)
        self.body_plot.setLabel("left", "角度", units="度")
        self.body_plot.setLabel("bottom", "时间", units="秒")
        self.body_plot.setTitle("👕 BNO1 (身体/腰部) - 连续角度变化")
        self.body_plot.setYRange(-180, 180, padding=0.0)
        self.body_plot.addLegend()

        self.body_roll_curve = self.body_plot.plot(
            pen=pg.mkPen("#ff4757", width=2), name="Roll (左右倾斜)")
        self.body_pitch_curve = self.body_plot.plot(
            pen=pg.mkPen("#2ed573", width=2), name="Pitch (前后俯仰)")
        self.body_yaw_curve = self.body_plot.plot(
            pen=pg.mkPen("#70a1ff", width=2), name="Yaw (左右转头)")

        layout.addWidget(self.body_plot)
        self.tab_widget.addTab(tab, "👕 BNO1 (身体)")

    def _setup_arm_tab(self):
        """设置 BNO2 (手臂) 标签页"""
        tab = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(tab)

        self.arm_plot = pg.PlotWidget()
        self.arm_plot.setBackground("#1a1a2e")
        self.arm_plot.showGrid(x=True, y=True, alpha=0.3)
        self.arm_plot.setLabel("left", "角度", units="度")
        self.arm_plot.setLabel("bottom", "时间", units="秒")
        self.arm_plot.setTitle("💪 BNO2 (手臂) - 连续角度变化")
        self.arm_plot.setYRange(-180, 180, padding=0.0)
        self.arm_plot.addLegend()

        self.arm_roll_curve = self.arm_plot.plot(
            pen=pg.mkPen("#ff4757", width=2), name="Roll (左右倾斜)")
        self.arm_pitch_curve = self.arm_plot.plot(
            pen=pg.mkPen("#2ed573", width=2), name="Pitch (前后俯仰)")
        self.arm_yaw_curve = self.arm_plot.plot(
            pen=pg.mkPen("#70a1ff", width=2), name="Yaw (左右转头)")

        layout.addWidget(self.arm_plot)
        self.tab_widget.addTab(tab, "💪 BNO2 (手臂)")

    def _clear_buffers(self):
        """清空所有数据缓存"""
        self.time_buf.clear()
        self.head_roll_buf.clear()
        self.head_pitch_buf.clear()
        self.head_yaw_buf.clear()
        self.body_roll_buf.clear()
        self.body_pitch_buf.clear()
        self.body_yaw_buf.clear()
        self.arm_roll_buf.clear()
        self.arm_pitch_buf.clear()
        self.arm_yaw_buf.clear()
        self.activity_intensity_buf.clear()
        self.base_time = None
        print("[波形] 已清空")

    def _toggle_freeze(self, checked):
        self._frozen = checked
        self.freeze_btn.setText("恢复" if checked else "冻结")

    def add_data(self, timestamp: float,
                 head_angles: tuple, body_angles: tuple, arm_angles: tuple,
                 activity_intensity: float = None):
        """添加一帧数据"""
        if self._frozen:
            return

        if self.base_time is None:
            self.base_time = timestamp

        rel_time = timestamp - self.base_time
        self.time_buf.append(rel_time)

        # BNO0
        self.head_roll_buf.append(head_angles[0])
        self.head_pitch_buf.append(head_angles[1])
        self.head_yaw_buf.append(head_angles[2])

        # BNO1
        self.body_roll_buf.append(body_angles[0])
        self.body_pitch_buf.append(body_angles[1])
        self.body_yaw_buf.append(body_angles[2])

        # BNO2
        self.arm_roll_buf.append(arm_angles[0])
        self.arm_pitch_buf.append(arm_angles[1])
        self.arm_yaw_buf.append(arm_angles[2])

        if activity_intensity is not None:
            self.activity_intensity_buf.append(activity_intensity)

        # 更新状态栏
        if len(self.time_buf) > 0:
            self.status_label.setText(
                f"实时 | 时间: {rel_time:.1f}s | 数据点: {len(self.time_buf)}")

    def _update_plots(self):
        """更新所有图表"""
        if self._frozen or len(self.time_buf) < 2:
            return

        times = np.array(list(self.time_buf))

        # 更新活动强度图
        if len(self.activity_intensity_buf) > 0:
            intensities = np.array(list(self.activity_intensity_buf))
            n = min(len(times), len(intensities))
            if n > 1:
                self.activity_curve.setData(times[-n:], intensities[-n:])
                max_int = np.max(intensities[-n:])
                if max_int > 0:
                    self.activity_plot.setYRange(0, min(100, max_int * 1.2))

        # 更新 BNO0
        if len(self.head_roll_buf) > 0:
            n = min(len(times), len(self.head_roll_buf))
            if n > 1:
                self.head_roll_curve.setData(times[-n:], np.array(list(self.head_roll_buf))[-n:])
                self.head_pitch_curve.setData(times[-n:], np.array(list(self.head_pitch_buf))[-n:])
                self.head_yaw_curve.setData(times[-n:], np.array(list(self.head_yaw_buf))[-n:])

                x_max = times[-1]
                x_min = 0
                self.head_plot.setXRange(x_min, x_max)

        # 更新 BNO1
        if len(self.body_roll_buf) > 0:
            n = min(len(times), len(self.body_roll_buf))
            if n > 1:
                self.body_roll_curve.setData(times[-n:], np.array(list(self.body_roll_buf))[-n:])
                self.body_pitch_curve.setData(times[-n:], np.array(list(self.body_pitch_buf))[-n:])
                self.body_yaw_curve.setData(times[-n:], np.array(list(self.body_yaw_buf))[-n:])

                x_max = times[-1]
                x_min = 0
                self.body_plot.setXRange(x_min, x_max)

        # 更新 BNO2
        if len(self.arm_roll_buf) > 0:
            n = min(len(times), len(self.arm_roll_buf))
            if n > 1:
                self.arm_roll_curve.setData(times[-n:], np.array(list(self.arm_roll_buf))[-n:])
                self.arm_pitch_curve.setData(times[-n:], np.array(list(self.arm_pitch_buf))[-n:])
                self.arm_yaw_curve.setData(times[-n:], np.array(list(self.arm_yaw_buf))[-n:])

                x_max = times[-1]
                x_min = 0
                self.arm_plot.setXRange(x_min, x_max)

    def closeEvent(self, event):
        self.update_timer.stop()
        super().closeEvent(event)