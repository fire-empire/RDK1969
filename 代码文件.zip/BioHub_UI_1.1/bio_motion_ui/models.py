import math
from dataclasses import dataclass
from typing import Optional, Tuple


@dataclass
class Sample:
    ts_s: float
    ad: Tuple[int, ...]
    quat: Tuple[Tuple[float, float, float, float], ...]
    max30102_red: int
    max30102_ir: int
    max30102_time_ms: int
    temperature_c: Tuple[Optional[float], Optional[float]]
    slow_update: bool = False


@dataclass
class RxStats:
    packet_count: int = 0
    rx_bytes: int = 0
    invalid_count: int = 0
    lost_count: int = 0
    duplicate_count: int = 0
    out_of_order_count: int = 0
    late_count: int = 0
    ad_lost_count: int = 0
    ad_duplicate_count: int = 0
    ad_recovered_count: int = 0
    dropped_in_buffer: int = 0
    last_seq: int = -1
    has_last_seq: bool = False
    transport_connected: bool = False
    last_error: str = ""


def quat_to_euler_deg(w: float, x: float, y: float, z: float) -> Tuple[float, float, float]:
    sinr_cosp = 2.0 * (w * x + y * z)
    cosr_cosp = 1.0 - 2.0 * (x * x + y * y)
    roll = math.atan2(sinr_cosp, cosr_cosp)

    sinp = 2.0 * (w * y - z * x)
    sinp = max(-1.0, min(1.0, sinp))
    pitch = math.asin(sinp)

    siny_cosp = 2.0 * (w * z + x * y)
    cosy_cosp = 1.0 - 2.0 * (y * y + z * z)
    yaw = math.atan2(siny_cosp, cosy_cosp)

    return math.degrees(roll), math.degrees(pitch), math.degrees(yaw)
