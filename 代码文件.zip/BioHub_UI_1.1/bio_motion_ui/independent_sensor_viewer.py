#!/usr/bin/env python3
"""
Independent Sensor Data Viewer - English Version with 3 Separate Windows
- Window 1: Motion Data (Head/Body/Arm Euler Angles + Activity Intensity)
- Window 2: Vital Signs (Heart Rate + SpO2)
- Window 3: Temperature (Inside + Outside)
"""

import math
import time
from collections import deque
from typing import Deque, List, Optional, Tuple

import numpy as np
import pyqtgraph as pg
from PyQt5 import QtCore, QtWidgets


class RelativeAngleTracker:
    """Real-time relative angle tracker - auto-zeroing when stationary"""

    def __init__(self, sensor_name: str, settle_threshold: float = 1.5, settle_duration: float = 0.8):
        self.sensor_name = sensor_name
        self.settle_threshold = settle_threshold
        self.settle_duration = settle_duration

        self.current_abs = (0.0, 0.0, 0.0)
        self.display_angles = (0.0, 0.0, 0.0)
        self.base_angles = (0.0, 0.0, 0.0)
        self.has_base = False

        self._last_timestamp = None
        self._last_angles = None
        self._settle_start_time = None
        self.is_moving = False

    def update(self, timestamp: float, abs_roll: float, abs_pitch: float, abs_yaw: float) -> Tuple[float, float, float]:
        """Update sensor data, return relative angles"""
        self.current_abs = (abs_roll, abs_pitch, abs_yaw)

        if self._last_timestamp is None:
            self._last_timestamp = timestamp
            self._last_angles = (abs_roll, abs_pitch, abs_yaw)
            return (0.0, 0.0, 0.0)

        dt = max(0.01, timestamp - self._last_timestamp)
        delta_roll = self._angle_diff(abs_roll, self._last_angles[0])
        delta_pitch = self._angle_diff(abs_pitch, self._last_angles[1])
        delta_yaw = self._angle_diff(abs_yaw, self._last_angles[2])
        change_rate = (delta_roll + delta_pitch + delta_yaw) / dt

        self._last_timestamp = timestamp
        self._last_angles = (abs_roll, abs_pitch, abs_yaw)

        is_currently_moving = change_rate > self.settle_threshold

        if is_currently_moving:
            self.is_moving = True
            self._settle_start_time = None
            if self.has_base:
                rel_roll = self._get_relative_angle(abs_roll, self.base_angles[0])
                rel_pitch = self._get_relative_angle(abs_pitch, self.base_angles[1])
                rel_yaw = self._get_relative_angle(abs_yaw, self.base_angles[2])
                self.display_angles = (rel_roll, rel_pitch, rel_yaw)
        else:
            if self.is_moving:
                self._settle_start_time = timestamp
                self.is_moving = False

            if self._settle_start_time is not None:
                settle_duration = timestamp - self._settle_start_time
                if settle_duration >= self.settle_duration:
                    self.base_angles = (abs_roll, abs_pitch, abs_yaw)
                    self.has_base = True
                    self.display_angles = (0.0, 0.0, 0.0)
                    self._settle_start_time = None

        return self.display_angles

    def _angle_diff(self, a1: float, a2: float) -> float:
        diff = abs(a2 - a1)
        return min(diff, 360 - diff)

    def _get_relative_angle(self, current: float, base: float) -> float:
        diff = current - base
        if diff > 180:
            diff -= 360
        elif diff < -180:
            diff += 360
        return diff

    def reset(self):
        self.has_base = False
        self.base_angles = (0.0, 0.0, 0.0)
        self.display_angles = (0.0, 0.0, 0.0)
        self._last_timestamp = None
        self._last_angles = None
        self._settle_start_time = None
        self.is_moving = False


class MotionDataWindow(QtWidgets.QMainWindow):
    """Window 1: Motion data - Head/Body/Arm Euler angles + Activity Intensity"""

    def __init__(self, parent=None, display_seconds: float = 30.0):
        super().__init__(parent)
        self.display_seconds = display_seconds
        self.setWindowTitle(f"Motion Data - Euler Angles & Activity (Last {display_seconds}s)")
        self.resize(1400, 900)

        central = QtWidgets.QWidget()
        self.setCentralWidget(central)
        layout = QtWidgets.QGridLayout(central)
        layout.setSpacing(8)
        layout.setContentsMargins(8, 8, 8, 8)

        self.plots = {}
        self.curves = {}
        self.data_buffers = {}

        buffer_size = int(display_seconds * 100) + 1000
        self.time_buf: Deque[float] = deque(maxlen=buffer_size)

        self._init_buffers(buffer_size)
        self._create_plots(layout)

        self.update_timer = QtCore.QTimer()
        self.update_timer.timeout.connect(self._update_plots)
        self.update_timer.start(50)

        self.trackers = {
            'head': RelativeAngleTracker('HEAD'),
            'body': RelativeAngleTracker('BODY'),
            'arm': RelativeAngleTracker('ARM'),
        }

        self._latest_data = {
            'head_angles': (0, 0, 0),
            'body_angles': (0, 0, 0),
            'arm_angles': (0, 0, 0),
            'intensity': 0,
            'timestamp': 0,
        }

    def _init_buffers(self, buffer_size: int):
        channels = [
            'head_roll', 'head_pitch', 'head_yaw',
            'body_roll', 'body_pitch', 'body_yaw',
            'arm_roll', 'arm_pitch', 'arm_yaw',
            'intensity'
        ]
        for ch in channels:
            self.data_buffers[ch] = deque(maxlen=buffer_size)

    def _create_plots(self, layout):
        colors = {
            'head': {'roll': '#ff6b6b', 'pitch': '#ffa502', 'yaw': '#ff7f50'},
            'body': {'roll': '#1e90ff', 'pitch': '#00ced1', 'yaw': '#3cb371'},
            'arm': {'roll': '#9b59b6', 'pitch': '#e74c3c', 'yaw': '#f39c12'},
        }

        # Head Angles
        head_plot = self._create_plot("HEAD Euler Angles (Auto-zero)", "Time (s)", "Angle (deg)", colors['head'])
        layout.addWidget(head_plot, 0, 0)
        self.plots['head'] = head_plot
        self.curves['head_roll'] = head_plot.plot([], [], pen=pg.mkPen(colors['head']['roll'], width=2), name="Roll")
        self.curves['head_pitch'] = head_plot.plot([], [], pen=pg.mkPen(colors['head']['pitch'], width=2), name="Pitch")
        self.curves['head_yaw'] = head_plot.plot([], [], pen=pg.mkPen(colors['head']['yaw'], width=2), name="Yaw")
        head_plot.setYRange(-90, 90)

        # Body Angles
        body_plot = self._create_plot("BODY Euler Angles (Auto-zero)", "Time (s)", "Angle (deg)", colors['body'])
        layout.addWidget(body_plot, 0, 1)
        self.plots['body'] = body_plot
        self.curves['body_roll'] = body_plot.plot([], [], pen=pg.mkPen(colors['body']['roll'], width=2), name="Roll")
        self.curves['body_pitch'] = body_plot.plot([], [], pen=pg.mkPen(colors['body']['pitch'], width=2), name="Pitch")
        self.curves['body_yaw'] = body_plot.plot([], [], pen=pg.mkPen(colors['body']['yaw'], width=2), name="Yaw")
        body_plot.setYRange(-90, 90)

        # Arm Angles
        arm_plot = self._create_plot("ARM Euler Angles (Auto-zero)", "Time (s)", "Angle (deg)", colors['arm'])
        layout.addWidget(arm_plot, 1, 0)
        self.plots['arm'] = arm_plot
        self.curves['arm_roll'] = arm_plot.plot([], [], pen=pg.mkPen(colors['arm']['roll'], width=2), name="Roll")
        self.curves['arm_pitch'] = arm_plot.plot([], [], pen=pg.mkPen(colors['arm']['pitch'], width=2), name="Pitch")
        self.curves['arm_yaw'] = arm_plot.plot([], [], pen=pg.mkPen(colors['arm']['yaw'], width=2), name="Yaw")
        arm_plot.setYRange(-90, 90)

        # Activity Intensity
        intensity_plot = self._create_plot("Activity Intensity", "Time (s)", "Intensity (deg/frame)", None)
        layout.addWidget(intensity_plot, 1, 1)
        self.plots['intensity'] = intensity_plot
        self.curves['intensity'] = intensity_plot.plot(
            [], [], pen=pg.mkPen('#ff4757', width=2.5), name="Intensity",
            fillLevel=0, brush=pg.mkBrush(255, 71, 87, 50)
        )
        threshold = pg.InfiniteLine(pos=3.0, angle=0, pen=pg.mkPen('#ffa502', width=1.5, style=QtCore.Qt.DashLine))
        intensity_plot.addItem(threshold)
        intensity_plot.setYRange(0, 50)

    def _create_plot(self, title: str, xlabel: str, ylabel: str, colors: dict = None) -> pg.PlotWidget:
        plot = pg.PlotWidget()
        plot.setBackground("#1e1e2f")
        plot.setTitle(title, color="#ffffff", size="12pt")
        plot.setLabel("left", ylabel, color="#aaaaaa", size="10pt")
        plot.setLabel("bottom", xlabel, color="#aaaaaa", size="10pt")
        plot.showGrid(x=True, y=True, alpha=0.2)
        plot.getAxis("left").setPen("#666666")
        plot.getAxis("bottom").setPen("#666666")
        plot.getAxis("left").setTextPen("#ffffff")
        plot.getAxis("bottom").setTextPen("#ffffff")
        if colors:
            plot.addLegend(offset=(10, 10), brush=pg.mkBrush(30, 30, 50, 200))
        return plot

    def add_data(self, timestamp: float, head_angles, body_angles, arm_angles, intensity: float):
        rel_head = self.trackers['head'].update(timestamp, head_angles[0], head_angles[1], head_angles[2])
        rel_body = self.trackers['body'].update(timestamp, body_angles[0], body_angles[1], body_angles[2])
        rel_arm = self.trackers['arm'].update(timestamp, arm_angles[0], arm_angles[1], arm_angles[2])

        self._latest_data = {
            'head_angles': rel_head,
            'body_angles': rel_body,
            'arm_angles': rel_arm,
            'intensity': intensity,
            'timestamp': timestamp,
        }

        self.time_buf.append(timestamp)
        self.data_buffers['head_roll'].append(rel_head[0])
        self.data_buffers['head_pitch'].append(rel_head[1])
        self.data_buffers['head_yaw'].append(rel_head[2])
        self.data_buffers['body_roll'].append(rel_body[0])
        self.data_buffers['body_pitch'].append(rel_body[1])
        self.data_buffers['body_yaw'].append(rel_body[2])
        self.data_buffers['arm_roll'].append(rel_arm[0])
        self.data_buffers['arm_pitch'].append(rel_arm[1])
        self.data_buffers['arm_yaw'].append(rel_arm[2])
        self.data_buffers['intensity'].append(intensity)

    def _update_plots(self):
        if len(self.time_buf) < 2:
            return

        time_arr = np.array(list(self.time_buf), dtype=np.float64)
        current_time = float(time_arr[-1])
        total_duration = current_time - time_arr[0]

        if total_duration < self.display_seconds:
            x_min = max(0, time_arr[0])
            x_max = current_time + 1
        else:
            x_min = current_time - self.display_seconds
            x_max = current_time

        margin = (x_max - x_min) * 0.05

        for sensor in ['head', 'body', 'arm']:
            for comp in ['roll', 'pitch', 'yaw']:
                buf_key = f"{sensor}_{comp}"
                if len(self.data_buffers[buf_key]) > 0:
                    data_arr = np.array(list(self.data_buffers[buf_key]), dtype=np.float64)
                    valid_len = min(len(data_arr), len(time_arr))
                    self.curves[f"{sensor}_{comp}"].setData(time_arr[-valid_len:], data_arr[-valid_len:])
            if sensor in self.plots:
                self.plots[sensor].setXRange(x_min - margin, x_max + margin, padding=0.0)

        if len(self.data_buffers['intensity']) > 0:
            data_arr = np.array(list(self.data_buffers['intensity']), dtype=np.float64)
            valid_len = min(len(data_arr), len(time_arr))
            self.curves['intensity'].setData(time_arr[-valid_len:], data_arr[-valid_len:])
            self.plots['intensity'].setXRange(x_min - margin, x_max + margin, padding=0.0)

    def get_data_duration(self) -> float:
        if len(self.time_buf) < 2:
            return 0
        return self.time_buf[-1] - self.time_buf[0]


class VitalSignsWindow(QtWidgets.QMainWindow):
    """Window 2: Vital signs - Heart Rate + SpO2"""

    def __init__(self, parent=None, display_seconds: float = 30.0):
        super().__init__(parent)
        self.display_seconds = display_seconds
        self.setWindowTitle(f"Vital Signs - Heart Rate & SpO2 (Last {display_seconds}s)")
        self.resize(900, 500)

        central = QtWidgets.QWidget()
        self.setCentralWidget(central)
        layout = QtWidgets.QGridLayout(central)
        layout.setSpacing(8)
        layout.setContentsMargins(8, 8, 8, 8)

        self.plots = {}
        self.curves = {}
        self.data_buffers = {}

        buffer_size = int(display_seconds * 100) + 1000
        self.time_buf: Deque[float] = deque(maxlen=buffer_size)

        self._init_buffers(buffer_size)
        self._create_plots(layout)

        self.update_timer = QtCore.QTimer()
        self.update_timer.timeout.connect(self._update_plots)
        self.update_timer.start(50)

        self._latest_data = {'hr': 0, 'spo2': 0, 'timestamp': 0}

    def _init_buffers(self, buffer_size: int):
        self.data_buffers['hr'] = deque(maxlen=buffer_size)
        self.data_buffers['spo2'] = deque(maxlen=buffer_size)

    def _create_plots(self, layout):
        # Heart Rate
        hr_plot = self._create_plot("Heart Rate (HR)", "Time (s)", "Heart Rate (bpm)")
        layout.addWidget(hr_plot, 0, 0)
        self.plots['hr'] = hr_plot
        self.curves['hr'] = hr_plot.plot([], [], pen=pg.mkPen('#e84118', width=2.5), name="Heart Rate")
        hr_plot.addItem(pg.InfiniteLine(pos=50, angle=0, pen=pg.mkPen('#2ed573', width=1, style=QtCore.Qt.DashLine),
                                        label="Normal min"))
        hr_plot.addItem(pg.InfiniteLine(pos=100, angle=0, pen=pg.mkPen('#ffa502', width=1, style=QtCore.Qt.DashLine),
                                        label="Normal max"))
        hr_plot.setYRange(40, 150)

        # SpO2
        spo2_plot = self._create_plot("Blood Oxygen (SpO₂)", "Time (s)", "SpO₂ (%)")
        layout.addWidget(spo2_plot, 0, 1)
        self.plots['spo2'] = spo2_plot
        self.curves['spo2'] = spo2_plot.plot([], [], pen=pg.mkPen('#0abde3', width=2.5), name="SpO₂")
        spo2_plot.addItem(pg.InfiniteLine(pos=94, angle=0, pen=pg.mkPen('#ff6b6b', width=1.5, style=QtCore.Qt.DashLine),
                                          label="Normal min"))
        spo2_plot.setYRange(70, 100)

    def _create_plot(self, title: str, xlabel: str, ylabel: str) -> pg.PlotWidget:
        plot = pg.PlotWidget()
        plot.setBackground("#1e1e2f")
        plot.setTitle(title, color="#ffffff", size="12pt")
        plot.setLabel("left", ylabel, color="#aaaaaa", size="10pt")
        plot.setLabel("bottom", xlabel, color="#aaaaaa", size="10pt")
        plot.showGrid(x=True, y=True, alpha=0.2)
        plot.getAxis("left").setPen("#666666")
        plot.getAxis("bottom").setPen("#666666")
        plot.getAxis("left").setTextPen("#ffffff")
        plot.getAxis("bottom").setTextPen("#ffffff")
        plot.addLegend(offset=(10, 10), brush=pg.mkBrush(30, 30, 50, 200))
        return plot

    def add_data(self, timestamp: float, hr: float, spo2: float):
        self._latest_data = {'hr': hr, 'spo2': spo2, 'timestamp': timestamp}
        self.time_buf.append(timestamp)
        self.data_buffers['hr'].append(hr if hr > 0 else np.nan)
        self.data_buffers['spo2'].append(spo2 if spo2 > 0 else np.nan)

    def _update_plots(self):
        if len(self.time_buf) < 2:
            return

        time_arr = np.array(list(self.time_buf), dtype=np.float64)
        current_time = float(time_arr[-1])
        total_duration = current_time - time_arr[0]

        if total_duration < self.display_seconds:
            x_min = max(0, time_arr[0])
            x_max = current_time + 1
        else:
            x_min = current_time - self.display_seconds
            x_max = current_time

        margin = (x_max - x_min) * 0.05

        for plot_name in ['hr', 'spo2']:
            if len(self.data_buffers[plot_name]) > 0:
                data_arr = np.array(list(self.data_buffers[plot_name]), dtype=np.float64)
                valid_len = min(len(data_arr), len(time_arr))
                self.curves[plot_name].setData(time_arr[-valid_len:], data_arr[-valid_len:])
                self.plots[plot_name].setXRange(x_min - margin, x_max + margin, padding=0.0)

    def get_data_duration(self) -> float:
        if len(self.time_buf) < 2:
            return 0
        return self.time_buf[-1] - self.time_buf[0]


class TemperatureWindow(QtWidgets.QMainWindow):
    """Window 3: Temperature data - Inside + Outside"""

    def __init__(self, parent=None, display_seconds: float = 30.0):
        super().__init__(parent)
        self.display_seconds = display_seconds
        self.setWindowTitle(f"Temperature - Inside Bed & Ambient (Last {display_seconds}s)")
        self.resize(900, 500)

        central = QtWidgets.QWidget()
        self.setCentralWidget(central)
        layout = QtWidgets.QGridLayout(central)
        layout.setSpacing(8)
        layout.setContentsMargins(8, 8, 8, 8)

        self.plots = {}
        self.curves = {}
        self.data_buffers = {}

        buffer_size = int(display_seconds * 100) + 1000
        self.time_buf: Deque[float] = deque(maxlen=buffer_size)

        self._init_buffers(buffer_size)
        self._create_plots(layout)

        self.update_timer = QtCore.QTimer()
        self.update_timer.timeout.connect(self._update_plots)
        self.update_timer.start(50)

        self._latest_data = {'temp_inside': None, 'temp_outside': None, 'timestamp': 0}

    def _init_buffers(self, buffer_size: int):
        self.data_buffers['temp_inside'] = deque(maxlen=buffer_size)
        self.data_buffers['temp_outside'] = deque(maxlen=buffer_size)

    def _create_plots(self, layout):
        # Inside Temperature
        inside_plot = self._create_plot("Inside Bed Temperature", "Time (s)", "Temperature (℃)")
        layout.addWidget(inside_plot, 0, 0)
        self.plots['temp_inside'] = inside_plot
        self.curves['temp_inside'] = inside_plot.plot([], [], pen=pg.mkPen('#ffa502', width=2.5), name="Inside")
        inside_plot.setYRange(20, 40)

        # Outside Temperature
        outside_plot = self._create_plot("Ambient Temperature", "Time (s)", "Temperature (℃)")
        layout.addWidget(outside_plot, 0, 1)
        self.plots['temp_outside'] = outside_plot
        self.curves['temp_outside'] = outside_plot.plot([], [], pen=pg.mkPen('#70a1ff', width=2.5), name="Ambient")
        outside_plot.setYRange(15, 35)

    def _create_plot(self, title: str, xlabel: str, ylabel: str) -> pg.PlotWidget:
        plot = pg.PlotWidget()
        plot.setBackground("#1e1e2f")
        plot.setTitle(title, color="#ffffff", size="12pt")
        plot.setLabel("left", ylabel, color="#aaaaaa", size="10pt")
        plot.setLabel("bottom", xlabel, color="#aaaaaa", size="10pt")
        plot.showGrid(x=True, y=True, alpha=0.2)
        plot.getAxis("left").setPen("#666666")
        plot.getAxis("bottom").setPen("#666666")
        plot.getAxis("left").setTextPen("#ffffff")
        plot.getAxis("bottom").setTextPen("#ffffff")
        plot.addLegend(offset=(10, 10), brush=pg.mkBrush(30, 30, 50, 200))
        return plot

    def add_data(self, timestamp: float, temp_inside: float = None, temp_outside: float = None):
        self._latest_data = {'temp_inside': temp_inside, 'temp_outside': temp_outside, 'timestamp': timestamp}
        self.time_buf.append(timestamp)
        self.data_buffers['temp_inside'].append(temp_inside if temp_inside is not None else np.nan)
        self.data_buffers['temp_outside'].append(temp_outside if temp_outside is not None else np.nan)

    def _update_plots(self):
        if len(self.time_buf) < 2:
            return

        time_arr = np.array(list(self.time_buf), dtype=np.float64)
        current_time = float(time_arr[-1])
        total_duration = current_time - time_arr[0]

        if total_duration < self.display_seconds:
            x_min = max(0, time_arr[0])
            x_max = current_time + 1
        else:
            x_min = current_time - self.display_seconds
            x_max = current_time

        margin = (x_max - x_min) * 0.05

        for plot_name in ['temp_inside', 'temp_outside']:
            if len(self.data_buffers[plot_name]) > 0:
                data_arr = np.array(list(self.data_buffers[plot_name]), dtype=np.float64)
                data_arr[np.isnan(data_arr)] = np.nan
                valid_len = min(len(data_arr), len(time_arr))
                self.curves[plot_name].setData(time_arr[-valid_len:], data_arr[-valid_len:])
                self.plots[plot_name].setXRange(x_min - margin, x_max + margin, padding=0.0)

    def get_data_duration(self) -> float:
        if len(self.time_buf) < 2:
            return 0
        return self.time_buf[-1] - self.time_buf[0]


class SimpleDataDisplay(QtWidgets.QWidget):
    """Compact numeric value display"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Live Sensor Values (Relative Angles)")
        self.setStyleSheet("background-color: #0f0f1a; color: white;")
        self.resize(550, 400)

        layout = QtWidgets.QVBoxLayout(self)

        title = QtWidgets.QLabel("📊 Live Sensor Values (Auto-zero)")
        title.setStyleSheet(
            "font-size: 16px; font-weight: bold; padding: 8px; background-color: #1a1a2e; border-radius: 5px;")
        title.setAlignment(QtCore.Qt.AlignCenter)
        layout.addWidget(title)

        info = QtWidgets.QLabel("💡 Stationary for ~1 sec → auto-zero")
        info.setStyleSheet("padding: 4px; background-color: #2d2d44; border-radius: 5px; color: #70a1ff;")
        info.setAlignment(QtCore.Qt.AlignCenter)
        layout.addWidget(info)

        grid = QtWidgets.QGridLayout()

        self.head_label = self._create_label("HEAD", "Roll: 0° | Pitch: 0° | Yaw: 0°", "#ff6b6b")
        grid.addWidget(self.head_label, 0, 0)

        self.body_label = self._create_label("BODY", "Roll: 0° | Pitch: 0° | Yaw: 0°", "#1e90ff")
        grid.addWidget(self.body_label, 1, 0)

        self.arm_label = self._create_label("ARM", "Roll: 0° | Pitch: 0° | Yaw: 0°", "#9b59b6")
        grid.addWidget(self.arm_label, 2, 0)

        self.intensity_label = self._create_label("ACTIVITY", "0.0 deg/frame", "#ff4757")
        grid.addWidget(self.intensity_label, 3, 0)

        self.hr_label = self._create_label("HEART RATE", "-- bpm", "#e84118")
        grid.addWidget(self.hr_label, 0, 1)

        self.spo2_label = self._create_label("SpO₂", "-- %", "#0abde3")
        grid.addWidget(self.spo2_label, 1, 1)

        self.temp_inside_label = self._create_label("BED TEMP", "-- ℃", "#ffa502")
        grid.addWidget(self.temp_inside_label, 2, 1)

        self.temp_outside_label = self._create_label("AMBIENT", "-- ℃", "#70a1ff")
        grid.addWidget(self.temp_outside_label, 3, 1)

        layout.addLayout(grid)

        self.status_label = QtWidgets.QLabel("Waiting for data...")
        self.status_label.setStyleSheet("padding: 6px; background-color: #1a1a2e; border-radius: 5px;")
        self.status_label.setAlignment(QtCore.Qt.AlignCenter)
        layout.addWidget(self.status_label)

        self.update_timer = QtCore.QTimer()
        self.update_timer.timeout.connect(self._update_display)
        self.update_timer.start(100)

        self._data = {}
        self._duration = 0

    def _create_label(self, title: str, value: str, color: str) -> QtWidgets.QLabel:
        label = QtWidgets.QLabel(f"<b>{title}</b><br><span style='color: {color}; font-size: 13px;'>{value}</span>")
        label.setStyleSheet("background-color: #1a1a2e; border-radius: 5px; padding: 8px; margin: 4px;")
        label.setAlignment(QtCore.Qt.AlignCenter)
        label.setMinimumWidth(220)
        return label

    def update_data(self, data: dict, duration: float = 0):
        self._data = data
        self._duration = duration

    def _update_display(self):
        if not self._data:
            return

        head = self._data.get('head_angles', (0, 0, 0))
        self.head_label.setText(f"<b>HEAD</b><br>"
                                f"<span style='color: #ff6b6b;'>Roll: {head[0]:+.1f}°</span> | "
                                f"<span style='color: #ffa502;'>Pitch: {head[1]:+.1f}°</span> | "
                                f"<span style='color: #ff7f50;'>Yaw: {head[2]:+.1f}°</span>")

        body = self._data.get('body_angles', (0, 0, 0))
        self.body_label.setText(f"<b>BODY</b><br>"
                                f"<span style='color: #1e90ff;'>Roll: {body[0]:+.1f}°</span> | "
                                f"<span style='color: #00ced1;'>Pitch: {body[1]:+.1f}°</span> | "
                                f"<span style='color: #3cb371;'>Yaw: {body[2]:+.1f}°</span>")

        arm = self._data.get('arm_angles', (0, 0, 0))
        self.arm_label.setText(f"<b>ARM</b><br>"
                               f"<span style='color: #9b59b6;'>Roll: {arm[0]:+.1f}°</span> | "
                               f"<span style='color: #e74c3c;'>Pitch: {arm[1]:+.1f}°</span> | "
                               f"<span style='color: #f39c12;'>Yaw: {arm[2]:+.1f}°</span>")

        intensity = self._data.get('intensity', 0)
        int_color = "#2ed573" if intensity < 3 else "#ffa502" if intensity < 10 else "#ff4757"
        self.intensity_label.setText(f"<b>ACTIVITY</b><br>"
                                     f"<span style='color: {int_color};'>{intensity:.1f} deg/frame</span>")

        hr = self._data.get('hr', 0)
        hr_color = "#2ed573" if 50 <= hr <= 100 else "#ffa502" if hr > 0 else "#666"
        hr_text = f"{hr:.0f} bpm" if hr > 0 else "-- bpm"
        self.hr_label.setText(f"<b>HEART RATE</b><br><span style='color: {hr_color};'>{hr_text}</span>")

        spo2 = self._data.get('spo2', 0)
        spo2_color = "#2ed573" if spo2 >= 94 else "#ff4757" if spo2 > 0 else "#666"
        spo2_text = f"{spo2:.0f}%" if spo2 > 0 else "--%"
        self.spo2_label.setText(f"<b>SpO₂</b><br><span style='color: {spo2_color};'>{spo2_text}</span>")

        temp_inside = self._data.get('temp_inside')
        if temp_inside and not np.isnan(temp_inside):
            self.temp_inside_label.setText(
                f"<b>BED TEMP</b><br><span style='color: #ffa502;'>{temp_inside:.1f}℃</span>")

        temp_outside = self._data.get('temp_outside')
        if temp_outside and not np.isnan(temp_outside):
            self.temp_outside_label.setText(
                f"<b>AMBIENT</b><br><span style='color: #70a1ff;'>{temp_outside:.1f}℃</span>")

        ts = self._data.get('timestamp', 0)
        if ts > 0:
            status = f"Last update: {time.strftime('%H:%M:%S', time.localtime(ts))}"
            if self._duration > 0:
                status += f"  |  Recorded: {self._duration:.1f}s"
            self.status_label.setText(status)


# Main viewer class that manages all windows
class IndependentSensorViewer:
    """Manager for all three sensor viewer windows"""

    def __init__(self, display_seconds: float = 30.0):
        self.display_seconds = display_seconds

        # Create three separate windows
        self.motion_window = MotionDataWindow(display_seconds=display_seconds)
        self.vital_window = VitalSignsWindow(display_seconds=display_seconds)
        self.temp_window = TemperatureWindow(display_seconds=display_seconds)
        self.value_display = SimpleDataDisplay()

        # Show all windows
        self.motion_window.show()
        self.vital_window.show()
        self.temp_window.show()
        self.value_display.show()

        # Position windows
        screen = QtWidgets.QApplication.primaryScreen().geometry()
        w_width = screen.width() // 2
        self.motion_window.resize(w_width, screen.height() // 2 + 100)
        self.vital_window.resize(w_width, screen.height() // 3)
        self.temp_window.resize(w_width, screen.height() // 3)

        self.motion_window.move(0, 0)
        self.vital_window.move(w_width, 0)
        self.temp_window.move(w_width, self.vital_window.height())
        self.value_display.move(0, self.motion_window.height())

        self._duration = 0

    def add_data(self, timestamp: float,
                 head_angles: Tuple[float, float, float],
                 body_angles: Tuple[float, float, float],
                 arm_angles: Tuple[float, float, float],
                 intensity: float,
                 hr: float = 0,
                 spo2: float = 0,
                 temp_inside: float = None,
                 temp_outside: float = None):
        # Update motion window
        self.motion_window.add_data(timestamp, head_angles, body_angles, arm_angles, intensity)

        # Update vital signs window
        self.vital_window.add_data(timestamp, hr, spo2)

        # Update temperature window
        self.temp_window.add_data(timestamp, temp_inside, temp_outside)

        # Update value display
        self._duration = self.motion_window.get_data_duration()
        self.value_display.update_data({
            'head_angles': head_angles,
            'body_angles': body_angles,
            'arm_angles': arm_angles,
            'intensity': intensity,
            'hr': hr,
            'spo2': spo2,
            'temp_inside': temp_inside,
            'temp_outside': temp_outside,
            'timestamp': timestamp,
        }, self._duration)

    def close_all(self):
        """Close all windows"""
        self.motion_window.close()
        self.vital_window.close()
        self.temp_window.close()
        self.value_display.close()

    def reset_calibration(self):
        """Reset all angle trackers"""
        for tracker in self.motion_window.trackers.values():
            tracker.reset()