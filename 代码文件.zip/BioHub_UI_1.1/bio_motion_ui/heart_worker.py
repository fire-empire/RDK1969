import sys
import threading
import time
from pathlib import Path
from typing import Dict, List

from PyQt5 import QtCore

from .config import SENSORS
from .receiver import BluetoothReceiverThread

try:
    import Max_30102
except ModuleNotFoundError:
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    import Max_30102


class HeartProcessorThread(QtCore.QThread):
    """Runs MAX30102 heart-rate analysis outside the UI and receive paths."""

    def __init__(self, receiver: BluetoothReceiverThread):
        super().__init__()
        self.receiver = receiver
        self.device = Max_30102.Device(
            sample_rate=SENSORS.max30102_window_points,
            avg_rate=4,
            serial_enabled=False,
        )
        self._stop_event = threading.Event()
        self._lock = threading.Lock()
        self._snapshot = self._empty_snapshot()

    def stop(self) -> None:
        self._stop_event.set()

    def get_snapshot(self) -> Dict:
        with self._lock:
            return {
                "times": list(self._snapshot["times"]),
                "ir_values": list(self._snapshot["ir_values"]),
                "peak_times_ms": list(self._snapshot["peak_times_ms"]),
                "peak_values": list(self._snapshot["peak_values"]),
                "data": dict(self._snapshot["data"]),
                "data_valid": self._snapshot["data_valid"],
            }

    def _empty_snapshot(self) -> Dict[str, object]:
        return {
            "times": [],
            "ir_values": [],
            "peak_times_ms": [],
            "peak_values": [],
            "data": dict(self.device.data),
            "data_valid": 0,
        }

    def _refresh_snapshot(self) -> None:
        if self.device.data_valid and len(self.device.ir_list_data_filtered) > 0:
            ir_values: List[float] = list(self.device.ir_list_data_filtered)
        else:
            ir_values = list(self.device.ir_list_data)

        with self._lock:
            self._snapshot = {
                "times": list(self.device.data_list_time),
                "ir_values": ir_values,
                "peak_times_ms": list(self.device.peak_times_ms),
                "peak_values": list(self.device.peak_values),
                "data": dict(self.device.data),
                "data_valid": self.device.data_valid,
            }

    def run(self) -> None:
        last_snapshot_s = 0.0
        while not self._stop_event.is_set():
            samples = self.receiver.pop_heart_samples()
            if samples:
                for red, ir, sample_time_ms in samples:
                    self.device.add_transport_sample(red, ir, sample_time_ms)

            now = time.monotonic()
            if samples or now - last_snapshot_s >= 0.10:
                self._refresh_snapshot()
                last_snapshot_s = now

            if not samples:
                self.msleep(5)
