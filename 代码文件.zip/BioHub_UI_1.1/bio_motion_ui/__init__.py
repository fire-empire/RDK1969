"""Realtime PC UI package for the bio-motion hub."""

from .app import main, parse_args
from .config import NETWORK, PLOT, PROTOCOL, SENSORS
from .heart_worker import HeartProcessorThread
from .models import RxStats, Sample, quat_to_euler_deg
from .receiver import BluetoothReceiverThread, UdpReceiverThread

__all__ = [
    "HeartProcessorThread",
    "NETWORK",
    "PLOT",
    "PROTOCOL",
    "RxStats",
    "SENSORS",
    "Sample",
    "BluetoothReceiverThread",
    "UdpReceiverThread",
    "__version__",
    "main",
    "parse_args",
    "quat_to_euler_deg",
]

__version__ = "0.1.0"
