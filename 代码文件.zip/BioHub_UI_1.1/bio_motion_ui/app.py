import argparse
import sys
from typing import Optional, Sequence

from PyQt5 import QtWidgets

from .config import NETWORK
from .receiver import BluetoothReceiverThread


class PortSelectDialog(QtWidgets.QDialog):
    def __init__(self, device_name: str, parent=None):
        super().__init__(parent)
        self.device_name = device_name
        self.setWindowTitle("Select Bluetooth Port")
        self.setModal(True)
        self.resize(720, 180)

        layout = QtWidgets.QVBoxLayout(self)

        self.status_label = QtWidgets.QLabel("Select the Bluetooth SPP COM port, then connect.")
        layout.addWidget(self.status_label)

        row = QtWidgets.QHBoxLayout()
        self.port_combo = QtWidgets.QComboBox()
        self.port_combo.setMinimumWidth(520)
        self.port_combo.setSizeAdjustPolicy(QtWidgets.QComboBox.AdjustToContents)
        row.addWidget(self.port_combo, stretch=1)

        refresh_button = QtWidgets.QPushButton("Refresh")
        refresh_button.clicked.connect(self.refresh_ports)
        row.addWidget(refresh_button)
        layout.addLayout(row)

        self.port_detail = QtWidgets.QLabel("")
        self.port_detail.setWordWrap(True)
        layout.addWidget(self.port_detail)

        buttons = QtWidgets.QDialogButtonBox(
            QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel
        )
        buttons.button(QtWidgets.QDialogButtonBox.Ok).setText("Connect")
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
        self.connect_button = buttons.button(QtWidgets.QDialogButtonBox.Ok)

        self.port_combo.currentIndexChanged.connect(self._update_detail)
        self.refresh_ports()

    def refresh_ports(self) -> None:
        previous = self.selected_port()
        self.port_combo.blockSignals(True)
        self.port_combo.clear()

        choices = BluetoothReceiverThread.port_choices(self.device_name)
        for port, label, is_bluetooth in choices:
            tag = "Bluetooth" if is_bluetooth else "Serial"
            self.port_combo.addItem(f"{port}  [{tag}]  {label}", port)

        self.port_combo.blockSignals(False)
        if previous:
            index = self.port_combo.findData(previous)
            if index >= 0:
                self.port_combo.setCurrentIndex(index)

        has_ports = self.port_combo.count() > 0
        self.connect_button.setEnabled(has_ports)
        if not has_ports:
            self.status_label.setText("No serial ports found. Pair the ESP32 Bluetooth device first.")
        else:
            self.status_label.setText("Select the Bluetooth SPP COM port, then connect.")
        self._update_detail()

    def selected_port(self) -> str:
        return self.port_combo.currentData() or ""

    def _update_detail(self) -> None:
        port = self.selected_port()
        if not port:
            self.port_detail.setText("")
            return
        self.port_detail.setText(
            f"Selected: {port}. If no data appears, reopen this dialog and choose the COM port "
            "whose probe result has valid_samples > 0."
        )


def parse_args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Bluetooth AD7606 + BNO055 + MAX30102 + temperature realtime viewer"
    )
    parser.add_argument(
        "--bt-port",
        default=NETWORK.bluetooth_port,
        help="Bluetooth SPP COM port, for example COM7. Empty means auto-connect.",
    )
    parser.add_argument(
        "--select-port",
        action="store_true",
        help="show the manual COM port selector before connecting",
    )
    parser.add_argument(
        "--baud",
        type=int,
        default=NETWORK.bluetooth_baud,
        help=f"serial baud hint, default {NETWORK.bluetooth_baud}",
    )
    parser.add_argument(
        "--device-name",
        default=NETWORK.bluetooth_name,
        help=f"Bluetooth device name, default {NETWORK.bluetooth_name}",
    )
    parser.add_argument(
        "--list-ports",
        action="store_true",
        help="list serial ports and exit",
    )
    parser.add_argument(
        "--probe-ports",
        action="store_true",
        help="try bluetooth COM ports and report whether valid frames are received",
    )
    return parser.parse_args(argv)


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = parse_args(argv)
    if args.list_ports:
        ports = BluetoothReceiverThread.describe_ports()
        print("\n".join(ports) if ports else "No serial ports found.")
        return 0
    if args.probe_ports:
        receiver = BluetoothReceiverThread(
            serial_port=args.bt_port,
            baudrate=args.baud,
            device_name=args.device_name,
        )
        print("\n".join(receiver.probe_ports()))
        return 0

    app = QtWidgets.QApplication.instance()
    if app is None:
        app = QtWidgets.QApplication(sys.argv if argv is None else list(argv))

    import pyqtgraph as pg

    from .heart_worker import HeartProcessorThread
    from .main_window import MainWindow

    pg.setConfigOptions(antialias=False, useOpenGL=False)

    bt_port = args.bt_port
    if args.select_port and not bt_port:
        dialog = PortSelectDialog(args.device_name)
        if dialog.exec_() != QtWidgets.QDialog.Accepted:
            return 0
        bt_port = dialog.selected_port()
        if not bt_port:
            return 0

    receiver = BluetoothReceiverThread(
        serial_port=bt_port,
        baudrate=args.baud,
        device_name=args.device_name,
        buffer_maxlen=60000,
    )
    receiver.start()

    heart_processor = HeartProcessorThread(receiver)
    heart_processor.start()

    win = MainWindow(receiver, heart_processor)
    win.show()

    return int(app.exec_())
