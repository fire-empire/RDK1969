from dataclasses import dataclass


@dataclass(frozen=True)
class NetworkConfig:
    bluetooth_name: str = "BioHub-BLE1"
    bluetooth_port: str = ""
    bluetooth_baud: int = 921600
    serial_timeout_s: float = 0.02
    serial_reconnect_s: float = 1.0
    serial_idle_reopen_s: float = 1.5
    serial_read_bytes: int = 4096
    serial_rx_buffer: int = 1024 * 1024
    rx_batch_max: int = 2048


@dataclass(frozen=True)
class SensorConfig:
    bno_count: int = 3
    ad_channel_count: int = 8
    temp_channel_count: int = 2
    max30102_expected_rate_hz: int = 200
    max30102_analysis_seconds: float = 8.0

    @property
    def max30102_window_points(self) -> int:
        return int(self.max30102_expected_rate_hz * self.max30102_analysis_seconds)

    @property
    def heart_queue_maxlen(self) -> int:
        return self.max30102_window_points * 3


@dataclass(frozen=True)
class PlotConfig:
    plot_window_seconds: float = 6.0
    ad_expected_rate_hz: int = 500
    ui_update_ms: int = 20
    bno_ui_update_ms: int = 100
    heart_ui_update_ms: int = 100
    status_ui_update_ms: int = 250
    max_ui_samples_per_frame: int = 1200
    ad_display_min: float = -10500.0
    ad_display_max: float = 10500.0
    xrange_update_step_s: float = 0.04
    plot_max_points: int = 2200
    max30102_plot_seconds: float = 6.0

    @property
    def max_points(self) -> int:
        return int(self.plot_window_seconds * self.ad_expected_rate_hz)


@dataclass(frozen=True)
class ProtocolConfig:
    reorder_window_packets: int = 2048
    redundant_magic: int = 0x4D42
    redundant_version: int = 2
    redundant_type_ad: int = 1
    redundant_type_full: int = 2
    redundant_type_heart: int = 3
    ad_redundancy: int = 4
    crc16_init: int = 0xFFFF


NETWORK = NetworkConfig()
SENSORS = SensorConfig()
PLOT = PlotConfig()
PROTOCOL = ProtocolConfig()
