import math
import time
from collections import deque
from typing import Deque, List, Optional, Tuple
from .waveform_viewer import WaveformViewer
from .comprehensive_sleep_analyzer import ComprehensiveSleepAnalyzer
from .independent_sensor_viewer import IndependentSensorViewer

import numpy as np
import pyqtgraph as pg
from PyQt5 import QtCore, QtWidgets

from .config import PLOT, SENSORS
from .heart_worker import HeartProcessorThread
from .models import quat_to_euler_deg
from .receiver import BluetoothReceiverThread


class MainWindow(QtWidgets.QMainWindow):
    """Realtime monitor window for AD7606, BNO055, MAX30102 and temperature."""

    def __init__(self, receiver: BluetoothReceiverThread, heart_processor: HeartProcessorThread):
        super().__init__()
        self.receiver = receiver
        self.heart_processor = heart_processor
        self.waveform_viewer = WaveformViewer()

        self.setWindowTitle("Bluetooth AD7606 + BNO055 + MAX30102 + Temperature Realtime Monitor")
        self.resize(1500, 1050)

        central = QtWidgets.QWidget()
        self.setCentralWidget(central)
        layout = QtWidgets.QVBoxLayout(central)

        self.status_label = QtWidgets.QLabel("starting...")
        self.status_label.setStyleSheet("font-size: 14px; padding: 6px;")
        layout.addWidget(self.status_label)

        self.bno_text = QtWidgets.QLabel("BNO: waiting data...")
        self.bno_text.setStyleSheet("font-size: 13px; padding: 6px;")
        layout.addWidget(self.bno_text)

        self.temp_text = QtWidgets.QLabel("TEMP: waiting data...")
        self.temp_text.setStyleSheet("font-size: 13px; padding: 6px;")
        layout.addWidget(self.temp_text)

        self.ad_plot = pg.PlotWidget()
        self.ad_plot.setBackground("#10151d")
        self.ad_plot.showGrid(x=True, y=True, alpha=0.25)
        self.ad_plot.addLegend(offset=(10, 10))
        self.ad_plot.setLabel("left", "AD7606 Value")
        self.ad_plot.setLabel("bottom", "Time", units="s")
        self.ad_plot.setTitle("AD7606 8-Channel")
        self.ad_plot.setYRange(PLOT.ad_display_min, PLOT.ad_display_max, padding=0.0)
        self.ad_plot.enableAutoRange(axis="y", enable=False)
        layout.addWidget(self.ad_plot, stretch=4)

        ad_colors = [
            "#ff595e",
            "#ff924c",
            "#ffca3a",
            "#8ac926",
            "#52a675",
            "#1982c4",
            "#4267ac",
            "#6a4c93",
        ]
        quat_colors = ["#ffd166", "#06d6a0", "#4cc9f0", "#ef476f"]

        self.ad_curves = []
        for i in range(SENSORS.ad_channel_count):
            curve = self.ad_plot.plot(
                [],
                [],
                pen=pg.mkPen(ad_colors[i], width=1.5),
                name=f"CH{i + 1}",
                antialias=False,
            )
            if hasattr(curve, "setClipToView"):
                curve.setClipToView(True)
            if hasattr(curve, "setDownsampling"):
                curve.setDownsampling(auto=True, method="peak")
            self.ad_curves.append(curve)

        heart_panel = QtWidgets.QWidget()
        heart_panel.setMinimumHeight(190)
        heart_layout = QtWidgets.QVBoxLayout(heart_panel)
        heart_layout.setContentsMargins(0, 0, 0, 0)
        heart_layout.setSpacing(6)

        self.heart_text = QtWidgets.QLabel("MAX30102: waiting data...")
        self.heart_text.setStyleSheet("font-size: 13px; padding: 6px;")
        heart_layout.addWidget(self.heart_text)

        self.heart_plot = pg.PlotWidget()
        self.heart_plot.setBackground("#10151d")
        self.heart_plot.showGrid(x=True, y=True, alpha=0.25)
        self.heart_plot.addLegend(offset=(8, 8))
        self.heart_plot.setLabel("left", "IR Value")
        self.heart_plot.setLabel("bottom", "Time", units="s")
        self.heart_plot.setTitle("IR Heart Rate Waveform")
        self.heart_plot.getPlotItem().getViewBox().invertY(True)
        heart_layout.addWidget(self.heart_plot, stretch=1)
        layout.addWidget(heart_panel, stretch=2)

        self.heart_ir_curve = self.heart_plot.plot(
            [],
            [],
            pen=pg.mkPen("#7bdff2", width=1.5),
            name="IR",
            antialias=False,
        )
        self.heart_peak_curve = self.heart_plot.plot(
            [],
            [],
            pen=None,
            symbol="o",
            symbolBrush="#ff477e",
            symbolPen=None,
            symbolSize=7,
            name="Beat",
        )

        bno_row = QtWidgets.QHBoxLayout()
        bno_row.setSpacing(8)
        layout.addLayout(bno_row, stretch=2)

        self.bno_plots = []
        self.bno_curves: List[List] = []
        for bno_idx in range(SENSORS.bno_count):
            plot = pg.PlotWidget()
            plot.setBackground("#10151d")
            plot.showGrid(x=True, y=True, alpha=0.25)
            plot.addLegend(offset=(8, 8))
            plot.setLabel("left", f"BNO{bno_idx} quat")
            plot.setLabel("bottom", "Time", units="s")
            plot.setTitle(f"BNO{bno_idx} Quaternion")
            plot.setYRange(-1.2, 1.2, padding=0.0)
            bno_row.addWidget(plot, stretch=1)
            self.bno_plots.append(plot)

            curves_one = []
            for comp_idx, comp in enumerate(("w", "x", "y", "z")):
                component_curve = plot.plot(
                    [],
                    [],
                    pen=pg.mkPen(quat_colors[comp_idx], width=1.4),
                    name=comp,
                    antialias=False,
                )
                curves_one.append(component_curve)
            self.bno_curves.append(curves_one)

        self.time_buf: Deque[float] = deque(maxlen=PLOT.max_points)
        self.ad_bufs: List[Deque[float]] = [
            deque(maxlen=PLOT.max_points) for _ in range(SENSORS.ad_channel_count)
        ]
        self.bno_time_buf: Deque[float] = deque(maxlen=PLOT.max_points)
        self.quat_bufs: List[List[Deque[float]]] = [
            [deque(maxlen=PLOT.max_points) for _ in range(4)]
            for _ in range(SENSORS.bno_count)
        ]

        self.latest_quat: List[Optional[Tuple[float, float, float, float]]] = [
            None
        ] * SENSORS.bno_count
        self.latest_temperature_c: Tuple[Optional[float], Optional[float]] = (None, None)

        self.base_ts: Optional[float] = None
        self.last_stat_t = time.monotonic()
        self.last_stat_packets = 0
        self.last_plot_x_max = -1.0
        self.last_bno_ui_s = 0.0
        self.last_heart_ui_s = 0.0
        self.last_status_ui_s = 0.0
        self.need_bno_redraw = False

        self.timer = QtCore.QTimer(self)
        self.timer.timeout.connect(self.update_ui)
        self.timer.start(PLOT.ui_update_ms)
        

        self.sleep_analyzer = ComprehensiveSleepAnalyzer()

        # ===== 添加独立数据视图 =====
        self.sensor_viewer = IndependentSensorViewer(display_seconds=30.0)


        self.program_start_time = time.time()
        self._last_angles = None

        self.add_temperature_plot()

        # 添加菜单栏
        menubar = self.menuBar()
        view_menu = menubar.addMenu("视图")

        show_waveform_action = view_menu.addAction("显示波形监控")
        show_waveform_action.triggered.connect(self._show_waveform)

        # 可以默认显示波形窗口（调试用）
        self.waveform_viewer.show()

    def _show_waveform(self):
        """显示波形查看器"""
        if hasattr(self, 'waveform_viewer'):
            self.waveform_viewer.show()
            self.waveform_viewer.raise_()




    @staticmethod
    def decimate_for_plot(x_arr: np.ndarray, y_arr: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        if x_arr.size <= PLOT.plot_max_points:
            return x_arr, y_arr

        stride = int(math.ceil(x_arr.size / PLOT.plot_max_points))
        return x_arr[::stride], y_arr[::stride]

    def update_ui(self) -> None:
        now = time.monotonic()
        samples = self.receiver.pop_all_samples(PLOT.max_ui_samples_per_frame)


        if samples:
            for sample in samples:
                if self.base_ts is None:
                    self.base_ts = sample.ts_s
                x = sample.ts_s - self.base_ts
                self.time_buf.append(x)




#1111   9轴传感器
                # 正确的代码（使用 BNO 四元数）
                # ========== 三传感器睡眠分析 + 波形显示 ==========
                if len(sample.quat) >= 3:
                    # 三个传感器的四元数
                    quat_head = sample.quat[0]  # BNO0 额头
                    quat_body = sample.quat[1]  # BNO1 身体
                    quat_arm = sample.quat[2]  # BNO2 手臂

                    # 转换为欧拉角用于波形显示
                    head_angles = self.sleep_analyzer.movement._quat_to_euler(*quat_head)
                    body_angles = self.sleep_analyzer.movement._quat_to_euler(*quat_body)
                    arm_angles = self.sleep_analyzer.movement._quat_to_euler(*quat_arm)
                    # 计算活动强度（帧间角度变化）
                    if self._last_angles is not None:
                        intensity = max(
                            abs(head_angles[0] - self._last_angles[0][0]),
                            abs(head_angles[1] - self._last_angles[0][1]),
                            abs(head_angles[2] - self._last_angles[0][2]),
                            abs(body_angles[0] - self._last_angles[1][0]),
                            abs(body_angles[1] - self._last_angles[1][1]),
                            abs(body_angles[2] - self._last_angles[1][2]),
                            abs(arm_angles[0] - self._last_angles[2][0]),
                            abs(arm_angles[1] - self._last_angles[2][1]),
                            abs(arm_angles[2] - self._last_angles[2][2])
                        )
                    else:
                        intensity = 0
                    self._last_angles = (head_angles, body_angles, arm_angles)

                    # 发送到波形查看器
                    if hasattr(self, 'waveform_viewer'):
                        self.waveform_viewer.add_data(
                            sample.ts_s,
                            head_angles, body_angles, arm_angles,
                            intensity
                        )

                    # 三传感器睡眠分析
                    self.sleep_analyzer.add_movement_data(x, quat_head, quat_body, quat_arm)
#1111

                    # ===== 新增：更新独立视图 =====
                    # 获取心率血氧数据
                    heart_snapshot = self.heart_processor.get_snapshot()
                    heart_data = heart_snapshot.get('data', {})
                    hr = heart_data.get('HR', 0)
                    spo2 = heart_data.get('SPO2', 0)

                    # 获取温度数据
                    temp1, temp2 = sample.temperature_c if sample.temperature_c else (None, None)

                    # 更新独立视图
                    self.sensor_viewer.add_data(
                        timestamp=x,
                        head_angles=head_angles,
                        body_angles=body_angles,
                        arm_angles=arm_angles,
                        intensity=intensity,
                        hr=hr,
                        spo2=spo2,
                        temp_inside=temp1,
                        temp_outside=temp2
                    )





                # 生命体征分析
                heart_snapshot = self.heart_processor.get_snapshot()
                heart_data = heart_snapshot.get('data', {})
                hr = heart_data.get('HR', 0)
                spo2 = heart_data.get('SPO2', 0)
                temp1, temp2 = sample.temperature_c if sample.temperature_c else (None, None)

                self.sleep_analyzer.add_vital_data(x, spo2=spo2, hr=hr,
                                                   temp_inside=temp1, temp_outside=temp2)





                for i in range(SENSORS.ad_channel_count):
                    self.ad_bufs[i].append(float(sample.ad[i]))

                if sample.slow_update:
                    self.bno_time_buf.append(x)
                    for bno_idx in range(SENSORS.bno_count):
                        quat = sample.quat[bno_idx]
                        self.latest_quat[bno_idx] = quat
                        for comp in range(4):
                            self.quat_bufs[bno_idx][comp].append(float(quat[comp]))
                    self.need_bno_redraw = True

                if any(value is not None for value in sample.temperature_c):
                    self.latest_temperature_c = sample.temperature_c
                    if self.base_ts is not None:                                           #这里
                        temp1, temp2 = sample.temperature_c
                        self._cache_temperature_data(x, temp1, temp2)

            x_arr = np.fromiter(self.time_buf, dtype=np.float64)

            for i in range(SENSORS.ad_channel_count):
                y_arr = np.fromiter(self.ad_bufs[i], dtype=np.float64)
                self.ad_curves[i].setData(x_arr, y_arr)

            if (
                self.need_bno_redraw
                and (now - self.last_bno_ui_s) * 1000.0 >= PLOT.bno_ui_update_ms
            ):
                self.last_bno_ui_s = now
                self.need_bno_redraw = False
                bno_x_arr = np.fromiter(self.bno_time_buf, dtype=np.float64)
                for bno_idx in range(SENSORS.bno_count):
                    for comp in range(4):
                        y_arr = np.fromiter(
                            self.quat_bufs[bno_idx][comp],
                            dtype=np.float64,
                        )
                        x_plot, y_plot = self.decimate_for_plot(bno_x_arr, y_arr)
                        self.bno_curves[bno_idx][comp].setData(x_plot, y_plot)

            if x_arr.size > 0:
                x_max = float(x_arr[-1])
                x_min = max(0.0, x_max - PLOT.plot_window_seconds)
                if x_max - self.last_plot_x_max >= PLOT.xrange_update_step_s:
                    self.last_plot_x_max = x_max
                    self.ad_plot.setXRange(x_min, x_max, padding=0.0)
                    for plot in self.bno_plots:
                        plot.setXRange(x_min, x_max, padding=0.0)

        if (now - self.last_heart_ui_s) * 1000.0 >= PLOT.heart_ui_update_ms:
            self.last_heart_ui_s = now
            self.update_heart_ui()

        stats = self.receiver.get_stats()
        if (now - self.last_status_ui_s) * 1000.0 < PLOT.status_ui_update_ms:
            return
        self.last_status_ui_s = now
        dt = now - self.last_stat_t
        rate_hz = 0.0
        if dt > 0:
            rate_hz = (stats.packet_count - self.last_stat_packets) / dt
        self.last_stat_t = now
        self.last_stat_packets = stats.packet_count

        self.status_label.setText(
            f"bt={'OK' if stats.transport_connected else 'WAIT'}  "
            f"rx={stats.packet_count}  rate={rate_hz:.1f} pkt/s  bytes={stats.rx_bytes}  "
            f"pkt_lost={stats.lost_count}  ad_lost={stats.ad_lost_count}  "
            f"ad_dup={stats.ad_duplicate_count}  invalid={stats.invalid_count}  "
            f"dup={stats.duplicate_count}  ooo={stats.out_of_order_count}  "
            f"late={stats.late_count}  buf_drop={stats.dropped_in_buffer}"
            f"{'  ' + stats.last_error if stats.last_error else ''}"
        )

        bno_lines = []
        for bno_idx in range(SENSORS.bno_count):
            quat = self.latest_quat[bno_idx]
            if quat is None:
                bno_lines.append(f"BNO{bno_idx}: waiting")
                continue

            w, x, y, z = quat
            norm = math.sqrt(w * w + x * x + y * y + z * z)
            roll, pitch, yaw = quat_to_euler_deg(w, x, y, z)
            is_valid = 0.7 <= norm <= 1.3
            tag = "OK" if is_valid else "WARN"
            bno_lines.append(
                f"BNO{bno_idx} [{tag}] norm={norm:.3f}  "
                f"R={roll:+6.1f}deg P={pitch:+6.1f}deg Y={yaw:+6.1f}deg"
            )

        self.bno_text.setText("    |    ".join(bno_lines))

        temp_lines = []
        for i, value in enumerate(self.latest_temperature_c):
            if value is None or not math.isfinite(value):
                temp_lines.append(f"T{i}: waiting")
            else:
                temp_lines.append(f"T{i}: {value:.2f}C")
        self.temp_text.setText("TEMP  " + "    |    ".join(temp_lines))
        self._update_temperature_curve()



    def update_heart_ui(self) -> None:
        heart = self.heart_processor.get_snapshot()
        times = heart["times"]
        ir_values = heart["ir_values"]
        n = min(len(times), len(ir_values))

        if n <= 0:
            self.heart_text.setText("MAX30102: waiting data...")
            return

        time_arr = np.asarray(times[-n:], dtype=np.float64)
        x_arr = (time_arr - time_arr[0]) * 1e-3
        ir_arr = np.asarray(ir_values[-n:], dtype=np.float64)

        self.heart_ir_curve.setData(x_arr, ir_arr)

        peak_times = np.asarray(heart["peak_times_ms"], dtype=np.float64)
        peak_values = np.asarray(heart["peak_values"], dtype=np.float64)
        if peak_times.size > 0 and peak_times.size == peak_values.size:
            visible = peak_times >= time_arr[0]
            self.heart_peak_curve.setData(
                (peak_times[visible] - time_arr[0]) * 1e-3,
                peak_values[visible],
            )
        else:
            self.heart_peak_curve.setData([], [])

        if x_arr.size > 0:
            x_max = float(x_arr[-1])
            x_min = max(0.0, x_max - PLOT.max30102_plot_seconds)
            self.heart_plot.setXRange(x_min, x_max, padding=0.0)
            y_min = float(np.min(ir_arr))
            y_max = float(np.max(ir_arr))
            if y_max > y_min:
                self.heart_plot.setYRange(y_min - 5.0, y_max + 5.0, padding=0.0)

        heart_data = heart["data"]
        hr_value = float(heart_data["HR"])
        hr_text = f"{hr_value:.0f}" if hr_value > 0 else "--"
        finger_text = "YES" if heart_data["Fin"] else "NO"
        quality = int(heart_data.get("Quality", 0))
        fs_hz = float(heart_data.get("Fs", 0.0))
        self.heart_text.setText(
            f"MAX30102  HR={hr_text} bpm  "
            f"Quality={quality}%  Fs={fs_hz:.0f}Hz  IR={heart_data['ir']}  "
            f"RED={heart_data['red']}  Finger={finger_text}"
        )

    def closeEvent(self, event):

        if hasattr(self, 'independent_viewer'):
            self.independent_viewer.close()
        if hasattr(self, 'data_display'):
            self.data_display.close()
        if hasattr(self, 'sensor_viewer'):
            self.sensor_viewer.close_all()

        # 保存综合睡眠报告
        if hasattr(self, 'sleep_analyzer'):
            run_duration = time.time() - self.program_start_time
            print(f"[DEBUG] 运行时长 = {run_duration:.2f} 秒")
            self.sleep_analyzer.finalize(run_duration)
            self.sleep_analyzer.print_full_report()  # 打印完整报告
            self.sleep_analyzer.save_report("comprehensive_sleep_report.json")

        self.timer.stop()
        self.heart_processor.stop()
        self.heart_processor.wait(1200)
        self.receiver.stop()
        self.receiver.wait(1200)
        super().closeEvent(event)






    def add_temperature_plot(self):
        """添加温度曲线图到界面最底部（不改变原有布局）"""
        from collections import deque

        # 获取中央布局
        central = self.centralWidget()
        layout = central.layout()

        # 创建温度曲线面板
        temp_panel = QtWidgets.QWidget()
        temp_panel.setMinimumHeight(200)
        temp_layout = QtWidgets.QVBoxLayout(temp_panel)
        temp_layout.setContentsMargins(0, 0, 0, 0)

        # 创建温度曲线图
        self.temp_plot = pg.PlotWidget()
        self.temp_plot.setBackground("#10151d")
        self.temp_plot.showGrid(x=True, y=True, alpha=0.25)
        self.temp_plot.addLegend(offset=(8, 8))
        self.temp_plot.setLabel("left", "Temperature", units="°C")
        self.temp_plot.setLabel("bottom", "Time", units="s")
        self.temp_plot.setTitle("Temperature Over Time")
        temp_layout.addWidget(self.temp_plot, stretch=1)

        # 添加温度曲线（两条）
        self.temp_curve1 = self.temp_plot.plot(
            [],
            [],
            pen=pg.mkPen("#f4d03f", width=2),
            name="Temp1",
            antialias=False,
        )
        self.temp_curve2 = self.temp_plot.plot(
            [],
            [],
            pen=pg.mkPen("#5dade2", width=2),
            name="Temp2",
            antialias=False,
        )

        # 添加到主布局底部
        layout.addWidget(temp_panel)

        # 初始化温度数据缓存
        self.temp_time_buf = deque(maxlen=PLOT.max_points)
        self.temp1_buf = deque(maxlen=PLOT.max_points)
        self.temp2_buf = deque(maxlen=PLOT.max_points)

    def _update_temperature_curve(self):
        """更新温度曲线（需要在 update_ui 中调用）"""
        if not hasattr(self, 'temp_plot'):
            return
        if len(self.temp_time_buf) <= 1:
            return

        temp_x_arr = np.fromiter(self.temp_time_buf, dtype=np.float64)
        temp1_arr = np.fromiter(self.temp1_buf, dtype=np.float64)
        temp2_arr = np.fromiter(self.temp2_buf, dtype=np.float64)

        # 去除 NaN 值
        mask1 = ~np.isnan(temp1_arr)
        if np.any(mask1):
            self.temp_curve1.setData(temp_x_arr[mask1], temp1_arr[mask1])
        mask2 = ~np.isnan(temp2_arr)
        if np.any(mask2):
            self.temp_curve2.setData(temp_x_arr[mask2], temp2_arr[mask2])

        # 设置 X 轴范围（跟随肌电图）
        if len(self.time_buf) > 0:
            x_max = float(self.time_buf[-1])
            x_min = max(0.0, x_max - PLOT.plot_window_seconds)
            self.temp_plot.setXRange(x_min, x_max, padding=0.0)

    def _cache_temperature_data(self, x, temp1, temp2):
        """缓存温度数据（需要在样本循环中调用）"""
        if not hasattr(self, 'temp_time_buf'):
            return
        self.temp_time_buf.append(x)
        self.temp1_buf.append(temp1 if temp1 is not None else float('nan'))
        self.temp2_buf.append(temp2 if temp2 is not None else float('nan'))